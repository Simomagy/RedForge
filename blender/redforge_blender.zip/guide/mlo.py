"""The Guide's flow for an interior (MLO): its models, the archetype that makes an interior of them, its rooms, the
portals between them, what's in each room, and the files.

The interior is the MLO archetype selected in the ytyp list (rooms, portals and entities find their archetype through
that selection, so the Guide keeps it there). Without an asset, as the Guide makes it, Blender's origin is the
interior's: rooms, portals and entities are placed from there."""
import os
import shutil
import tempfile

import bpy
from bpy.props import IntProperty, StringProperty
from mathutils import Vector

from . import core
from .core import DONE, OPTIONAL, PROBLEM, TODO, Flow, Step, flow, select_only, text
from .ydr import archetype_of, fix_mesh_data, game_name, materials_of, models_of, plain_meshes, write_ytd
from ..sollumz_preferences import get_export_settings
from ..lods import SOLLUMZ_OT_HIDE_COLLISIONS, SOLLUMZ_OT_SHOW_COLLISIONS, set_all_lods
from ..sollumz_properties import BOUND_TYPES, ArchetypeType, LODLevel, MaterialType, SollumType
from ..tools.blenderhelper import duplicate_object
from ..tools.boundhelper import convert_obj_to_bvh, convert_objs_to_single_composite
from ..tools.drawablehelper import center_drawable_to_models, convert_obj_to_drawable, convert_objs_to_single_drawable
from ..ybn.collision_materials import create_collision_material_from_index
from ..ybn.ui import SOLLUMZ_UL_COLLISION_MATERIALS_LIST
from ..ydr.operators.materials import MaterialConverter
from ..ytyp.utils import get_selected_ytyp

LIMBO = "limbo"  # the room that stands for the outside: the first one, as the game's interiors have it
# What the game's own interiors have (25 of them looked at), where Sollumz's defaults differ:
ROOM_FLAGS = "32"  # every limbo, and 57 of the 59 other rooms
ENTITY_FLAGS = "1572864"  # by far the most common flags of an interior's entity, in limbo and in rooms
TIMECYCLE = "val_genstore_int"  # a room always names a timecycle modifier of the game's, usually its interior's own
NOT_RDR_TIMECYCLES = ("int_gasstation",)  # Sollumz's default for a room: GTA V's, not in RDR2's timecycle files


def selected_mlo(context):
    """The archetype selected in the ytyp list, when it's an interior."""
    ytyp = get_selected_ytyp(context)
    archetype = ytyp.selected_archetype if (ytyp is not None and len(ytyp.archetypes)) else None
    return archetype if (archetype is not None and archetype.type == ArchetypeType.MLO) else None


def find_mlo(context, uuid: str):
    """(ytyp index, archetype index, archetype) of the interior with this uuid."""
    return next((found for found in all_mlos(context) if found[2].uuid == uuid), None) if uuid else None


def mlo_of(context):
    """The interior being worked on: the one the Guide was started on or made, whatever is selected in the ytyp list
    since; without one, the selected archetype when it's an interior."""
    found = find_mlo(context, context.scene.rf_guide.mlo)
    return found[2] if found is not None else selected_mlo(context)


def is_selected(context, mlo) -> bool:
    """Whether the interior is the archetype selected in the ytyp list: rooms, portals and entities find their
    archetype, and the lists of rooms to choose from are made, from that selection."""
    selected = selected_mlo(context)
    return selected is not None and selected.uuid == mlo.uuid


def select_mlo(context, uuid: str):
    """Makes the interior the selected archetype again, and the Guide's."""
    found = find_mlo(context, uuid)
    if found is None:
        return None
    ytyp_index, index, archetype = found
    if not is_selected(context, archetype):
        context.scene.ytyp_index = ytyp_index
        context.scene.ytyps[ytyp_index].archetypes.select(index)
    context.scene.rf_guide.mlo = uuid
    return context.scene.ytyps[ytyp_index].archetypes[index]


def all_mlos(context):
    """(ytyp index, archetype index, archetype) of every interior in the scene."""
    return [(i, j, archetype) for i, ytyp in enumerate(context.scene.ytyps)
            for j, archetype in enumerate(ytyp.archetypes) if archetype.type == ArchetypeType.MLO]


def parts(context):
    """The models an interior can be made of: every drawable and fragment in the scene."""
    return [obj for obj in context.scene.objects
            if obj.sollum_type in (SollumType.DRAWABLE, SollumType.FRAGMENT) and obj.parent is None]


def parts_to_fix(context):
    """The drawables with a material that isn't a game shader, or a mesh without one."""
    wrong = []
    for obj in parts(context):
        if obj.sollum_type != SollumType.DRAWABLE:
            continue
        materials, bare = materials_of(obj)
        if bare or any(m.sollum_type != MaterialType.SHADER for m in materials):
            wrong.append(obj)
    return wrong


def shell_of(context, guide):
    obj = guide.shell
    return obj if (obj is not None and obj.name in context.scene.objects and obj.sollum_type == SollumType.DRAWABLE) else None


def selected_models(context):
    """The drawables the selected objects are, or are part of (a model's mesh selected is the model selected)."""
    found = []
    for obj in context.selected_objects:
        while obj is not None and obj.sollum_type != SollumType.DRAWABLE:
            obj = obj.parent
        if obj is not None and obj not in found:
            found.append(obj)
    return found


def collision_of(context, guide):
    """The interior's collision: the bound composite the interior is on, or the one made for an interior to come."""
    mlo = mlo_of(context)
    if mlo is not None:
        asset = mlo.asset
        return asset if (asset is not None and asset.sollum_type == SollumType.BOUND_COMPOSITE) else None
    obj = guide.collision
    return obj if (obj is not None and obj.name in context.scene.objects and obj.sollum_type == SollumType.BOUND_COMPOSITE) else None


def collision_meshes_of(collision):
    return [obj for obj in collision.children_recursive if obj.type == "MESH"]


def bounds_under(obj):
    return [child for child in obj.children_recursive if child.sollum_type in BOUND_TYPES]


def is_limbo(room) -> bool:
    return room.name.lower() == LIMBO


def rooms_of(mlo):
    """The interior's rooms, without the outside."""
    return [room for room in mlo.rooms if not is_limbo(room)]


def has_bounds(room) -> bool:
    return any(abs(a - b) > 1e-4 for a, b in zip(room.bb_min, room.bb_max))


def origin_inverse(mlo):
    """World space to the interior's: from its asset when it has one, Blender's origin otherwise."""
    from mathutils import Matrix
    return mlo.asset.matrix_world.inverted() if mlo.asset is not None else Matrix()


def bounds_of_objects(objects, matrix):
    """The box around the objects and what's under them, in the space the matrix leads to."""
    corners = [matrix @ obj.matrix_world @ Vector(corner) for root in objects
               for obj in (root, *root.children_recursive) if obj.type == "MESH" for corner in obj.bound_box]
    if not corners:
        return None
    return (Vector((min(c.x for c in corners), min(c.y for c in corners), min(c.z for c in corners))),
            Vector((max(c.x for c in corners), max(c.y for c in corners), max(c.z for c in corners))))


def refresh_limbo(mlo):
    """The outside's box: around the whole collision (what Create Limbo Room gives it) and every room. The game's own
    interiors follow no rule here (of 25 looked at, the limbo's box was inside the rooms' somewhere in 24), so nothing
    depends on it: this is the one that leaves nothing out."""
    limbo = next((room for room in mlo.rooms if is_limbo(room)), None)
    boxes = [(Vector(room.bb_min), Vector(room.bb_max)) for room in rooms_of(mlo) if has_bounds(room)]
    if mlo.asset is not None:
        around = bounds_of_objects([mlo.asset], origin_inverse(mlo))
        if around is not None:
            boxes.append(around)
    if limbo is None or not boxes:
        return
    limbo.bb_min = [min(low[i] for low, _ in boxes) for i in range(3)]
    limbo.bb_max = [max(high[i] for _, high in boxes) for i in range(3)]


def room_names(mlo) -> dict[str, str]:
    return {str(room.id): room.name for room in mlo.rooms}


def portal_label(mlo, index: int, portal) -> str:
    names = room_names(mlo)  # (not the portal's own name: reading it writes its cache, which a panel can't)
    return f"{index + 1}  {names.get(portal.room_from_id, '?')} > {names.get(portal.room_to_id, '?')}"


# From and To, as the game's own interiors have them (25 of them looked at, 315 portals):
# - a portal to the outside has the room as From and limbo as To: all 267 of them, never the other way round;
# - a portal faces To: its arrow (the way its corners turn) points away from the From room, in 253 of the 265 where
#   the room's box tells;
# - between two rooms either one is From (31 had the earlier room in the list, 17 the later).


def portal_facing(mlo, portal):
    """True when the portal's arrow points from its From room to its To room, False when it points back into From,
    None when the rooms' boxes don't tell (no box, or the portal isn't on a side of it)."""
    corners = [Vector(c) for c in (portal.corner1, portal.corner2, portal.corner3, portal.corner4)]
    normal = (corners[1] - corners[0]).cross(corners[2] - corners[0])  # (the arrow the portals' gizmo draws)
    if normal.length < 1e-6:
        return None
    normal.normalize()
    centre = sum(corners, Vector()) / 4
    rooms = {str(room.id): room for room in mlo.rooms}
    for room_id, inward in ((portal.room_from_id, False), (portal.room_to_id, True)):
        room = rooms.get(room_id)
        if room is None or is_limbo(room) or not has_bounds(room):
            continue
        side = normal.dot((Vector(room.bb_min) + Vector(room.bb_max)) * 0.5 - centre)  # (> 0: the arrow points into it)
        if abs(side) > 0.05:
            return (side > 0) == inward
    return None


def limbo_is_from(mlo, portal) -> bool:
    rooms = {str(room.id): room for room in mlo.rooms}
    room = rooms.get(portal.room_from_id)
    return room is not None and is_limbo(room)


def portal_wrong(mlo, portal) -> str:
    if "-1" in (portal.room_from_id, portal.room_to_id):
        return "a side has no room"
    if portal.room_from_id == portal.room_to_id:
        return "same room on both sides"
    if all(abs(v) < 1e-6 for corner in (portal.corner1, portal.corner2, portal.corner3, portal.corner4) for v in corner):
        return "no corners"
    if limbo_is_from(mlo, portal):
        return "limbo is From"
    if portal_facing(mlo, portal) is False:
        return "arrow points back"
    return ""


def flip(portal):
    corners = [Vector(c) for c in (portal.corner1, portal.corner2, portal.corner3, portal.corner4)]
    portal.corner1, portal.corner2, portal.corner3, portal.corner4 = reversed(corners)


def set_right(mlo, portal) -> list[str]:
    """Puts From and To the way the game has them: limbo as To, the arrow from From to To. What it changed."""
    changed = []
    if limbo_is_from(mlo, portal) and portal.room_to_id not in ("-1", portal.room_from_id):
        portal.room_from_id, portal.room_to_id = portal.room_to_id, portal.room_from_id
        changed.append("From and To swapped (limbo is always To)")
    if portal_facing(mlo, portal) is False:
        flip(portal)
        changed.append("turned to face To")
    return changed


def entity_of(mlo, obj):
    return next((entity for entity in mlo.entities if entity.linked_object == obj), None)


def unplaced(entity) -> bool:
    return entity.attached_room_id == "-1" and entity.attached_portal_id == "-1"


def off_the_games(mlo) -> list[str]:
    """Where the interior has values the game's own never have: rooms and entities made with Sollumz's defaults."""
    off = []
    rooms = sum(1 for room in mlo.rooms if room.flags.total in ("", "0"))
    if rooms:
        off.append(f"{rooms} room(s) have no flags (the game's have {ROOM_FLAGS})")
    timecycles = sum(1 for room in rooms_of(mlo) if room.timecycle in NOT_RDR_TIMECYCLES or not room.timecycle)
    if timecycles:
        off.append(f"{timecycles} room(s) have no lighting of the game's (a timecycle that isn't in RDR2, or none)")
    entities = sum(1 for entity in mlo.entities if entity.flags.total in ("", "0"))
    if entities:
        off.append(f"{entities} entity(ies) have no flags (the game's have {ENTITY_FLAGS})")
    return off


def set_the_games(mlo):
    for room in mlo.rooms:
        if room.flags.total in ("", "0"):
            room.flags.total = ROOM_FLAGS
        if not is_limbo(room) and (room.timecycle in NOT_RDR_TIMECYCLES or not room.timecycle):
            room.timecycle = TIMECYCLE
    for entity in mlo.entities:
        if entity.flags.total in ("", "0"):
            entity.flags.total = ENTITY_FLAGS


def shell_misplaced(context, mlo):
    """The shell's entity, when it isn't in limbo. It goes there in the game's interiors (the shell is in limbo in 22
    of 25 looked at, with its shadow and reflection proxies; rooms have the furniture and details): it's what is seen
    of the building from every room and from outside."""
    shell = shell_of(context, context.scene.rf_guide)
    entity = entity_of(mlo, shell) if shell is not None else None
    limbo = next((room for room in mlo.rooms if is_limbo(room)), None)
    if entity is None or limbo is None or entity.attached_room_id == str(limbo.id):
        return None
    return entity


def without_archetype(context, mlo):
    """The interior's models with no archetype of their own: the game wouldn't know what the entity is."""
    return [entity.linked_object for entity in mlo.entities
            if entity.linked_object is not None and archetype_of(context, entity.linked_object)[1] is None]


def needs_mlo(layout, context) -> bool:
    mlo = mlo_of(context)
    if mlo is None:
        text(layout, context, "There's no interior yet: make it in step 3.", icon="INFO")
        return True
    if not is_selected(context, mlo):  # (something else was picked in the ytyp list, with the Expert Tools)
        text(layout, context, f"Another archetype is selected in the ytyp list: {mlo.name} has to be, to work on it.", icon="INFO")
        found = find_mlo(context, mlo.uuid)
        op = layout.operator(REDFORGE_OT_guide_mlo_use.bl_idname, text=f"Back to {mlo.name}", icon="LOOP_BACK")
        op.ytyp, op.archetype = found[0], found[1]
        return True
    return False


# ---- steps


class Shell(Step):
    label = "Shell"
    intro = ("The interior's own geometry: walls, floor, ceiling, stairs, as one static model. It has no collision of "
             "its own: that's a separate object, made in the next step.")

    def status(self, context, guide):
        shell = shell_of(context, guide)
        wrong = parts_to_fix(context)
        if wrong:
            return PROBLEM, f"{len(wrong)} to fix"
        if shell is not None:
            return DONE, shell.name
        mlo = mlo_of(context)
        if mlo is not None and len(mlo.entities):
            return DONE, f"{len(parts(context))} model(s)"
        return TODO, "select meshes" if not plain_meshes(context) else "ready"

    def draw(self, layout, context, guide):
        shell = shell_of(context, guide)
        meshes = plain_meshes(context)
        if shell is not None:
            layout.label(text=f"{shell.name} is the shell", icon="CHECKMARK")
            if bounds_under(shell):
                text(layout, context, "It has a collision inside it: the interior's collision is a separate object (step 2). "
                     "Remove this one with Model (YDR), step 5.", icon="ERROR")
            text(layout, context, "Its textures, levels of detail and name are set like any model's: Model (YDR), Continue with It.")
            layout.operator(REDFORGE_OT_guide_mlo_shell.bl_idname, text="Start Another Interior's Shell", icon="ADD").action = "NEW"
        else:
            models = selected_models(context)
            if context.mode != "OBJECT":
                text(layout, context, "Go back to Object Mode to make the shell.", icon="INFO")
            elif len(models) == 1 and not meshes:
                # (already a model, made with Model (YDR) or imported: nothing to make, it's chosen)
                text(layout, context, f"{models[0].name} is a model already.", icon="INFO")
                row = layout.row()
                row.scale_y = 1.4
                row.operator(REDFORGE_OT_guide_mlo_shell.bl_idname, text=f"{models[0].name} Is the Shell", icon="CHECKMARK").action = "USE"
            elif len(models) > 1 and not meshes:
                text(layout, context, f"{len(models)} models are selected: select only the one that is the shell.", icon="INFO")
            else:
                layout.prop(guide, "name")
                row = layout.row()
                row.scale_y = 1.4
                row.enabled = bool(meshes)
                row.operator(REDFORGE_OT_guide_mlo_shell.bl_idname, icon="OUTLINER_OB_MESH",
                             text=f"Make the Shell of {len(meshes)} Selected Mesh(es)" if meshes else "Make the Shell").action = "MAKE"
                if not meshes:
                    text(layout, context, "Nothing to make it of yet: select the meshes of the building's inside, or the model that is the shell already.", icon="INFO")
                else:
                    text(layout, context, "They become one model, their materials converted.")

        layout.separator()
        layout.label(text="Furniture, doors, lamps", icon="MESH_CUBE")
        text(layout, context, "Each is a model of its own, placed in the interior in step 6. They can be added later.")
        row = layout.row()
        row.enabled = bool(meshes) and shell is not None and context.mode == "OBJECT"
        row.operator(REDFORGE_OT_guide_mlo_make_models.bl_idname, icon="ADD",
                     text=f"Make {len(meshes)} Selected Mesh(es) Models" if meshes else "Make the Selected Meshes Models")
        wrong = parts_to_fix(context)
        if wrong:
            text(layout, context, f"{len(wrong)} model(s) have materials that aren't game shaders: "
                 f"{', '.join(obj.name for obj in wrong[:4])}{'...' if len(wrong) > 4 else ''}.", icon="ERROR")
            layout.operator(REDFORGE_OT_guide_mlo_fix_models.bl_idname, icon="FILE_REFRESH")


class Collision(Step):
    label = "Collision"
    intro = ("What's walked on and bumped into. It's an object of its own, apart from the shell (a .ybn file), and the "
             "interior is built on it: rooms, portals and entities are placed from it.")

    def status(self, context, guide):
        collision = collision_of(context, guide)
        if collision is None:
            return TODO, ""
        return DONE, f"{len(collision_meshes_of(collision))} mesh(es)"

    def draw(self, layout, context, guide):
        collision = collision_of(context, guide)
        wm = context.window_manager
        if collision is None:
            shell = shell_of(context, guide)
            layout.label(text="What it's made of (sounds, bullet marks)")
            layout.template_list(SOLLUMZ_UL_COLLISION_MATERIALS_LIST.bl_idname, "rf_guide_mlo", wm, "sz_collision_materials",
                                 wm, "sz_collision_material_index", rows=4)
            col = layout.column(align=True)
            col.scale_y = 1.2
            row = col.row(align=True)
            row.enabled = shell is not None
            row.operator(REDFORGE_OT_guide_mlo_collision.bl_idname, text="From the Shell's Shape", icon="MESH_DATA").source = "SHELL"
            row = col.row(align=True)
            row.enabled = bool(plain_meshes(context))
            row.operator(REDFORGE_OT_guide_mlo_collision.bl_idname, text="From the Selected Mesh(es)", icon="RESTRICT_SELECT_OFF").source = "SELECTED"
            text(layout, context, "Meshes made for it (flat floors, plain walls, no small details) are lighter for the game "
                 "than the shell's own shape. The shell itself isn't changed either way.")
            return
        layout.label(text=collision.name, icon="CHECKMARK")
        col = layout.column(align=True)
        for obj in collision_meshes_of(collision):
            row = col.row()
            row.label(text=obj.name, icon="MESH_DATA")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.label(text=", ".join(m.name for m in obj.data.materials if m is not None) or "no material")
        layout.prop(guide, "collision_material_shown", icon="MATERIAL", toggle=True)
        if guide.collision_material_shown:
            layout.template_list(SOLLUMZ_UL_COLLISION_MATERIALS_LIST.bl_idname, "rf_guide_mlo", wm, "sz_collision_materials",
                                 wm, "sz_collision_material_index", rows=4)
            layout.operator(REDFORGE_OT_guide_mlo_collision.bl_idname, text="Use This Material").source = "MATERIAL"
        row = layout.row(align=True)
        if context.scene.sollumz_show_collisions:
            row.operator(SOLLUMZ_OT_HIDE_COLLISIONS.bl_idname, icon="HIDE_OFF")
        else:
            row.operator(SOLLUMZ_OT_SHOW_COLLISIONS.bl_idname, icon="HIDE_ON")
        if mlo_of(context) is None or mlo_of(context).asset != collision:
            row.operator(REDFORGE_OT_guide_mlo_collision.bl_idname, text="Remove", icon="TRASH").source = "REMOVE"
        more = plain_meshes(context)
        if more:
            layout.operator(REDFORGE_OT_guide_mlo_collision.bl_idname, text=f"Add {len(more)} Selected Mesh(es) to It", icon="ADD").source = "ADD"
        text(layout, context, "It's solid for everything. Its flags (a part only for bullets, a stair slope...), simple shapes "
             "and a material per face: Home, Collision (YBN), Continue with It, with the collision selected.")


class Interior(Step):
    label = "Interior"
    intro = ("The archetype that makes an interior of all this, in its own .ytyp. It's made on the collision, which "
             "takes its name: the collision's origin is the interior's.")

    def status(self, context, guide):
        mlo = mlo_of(context)
        return (DONE, mlo.name) if mlo is not None else (TODO, "")

    def draw(self, layout, context, guide):
        mlo = mlo_of(context)
        if mlo is not None:
            layout.prop(mlo, "name", text="Name")
            layout.label(text=f"In {get_selected_ytyp(context).name}.ytyp", icon="CHECKMARK")
        others = [(i, j, a) for i, j, a in all_mlos(context) if mlo is None or a.uuid != mlo.uuid]
        if others:
            layout.label(text="Other interiors in this file")
            col = layout.column(align=True)
            for i, j, archetype in others:
                op = col.operator(REDFORGE_OT_guide_mlo_use.bl_idname, text=archetype.name, icon="MOD_BUILD")
                op.ytyp, op.archetype = i, j
        collision = collision_of(context, guide)
        if mlo is not None and mlo.asset is not None:
            layout.label(text=f"On {mlo.asset.name}", icon="CHECKMARK")
            if game_name(mlo.asset.name) != game_name(mlo.name):
                text(layout, context, "The collision has another name: the game finds the interior's collision by the interior's name.", icon="ERROR")
                layout.operator(REDFORGE_OT_guide_mlo_shell.bl_idname, text="Name the Collision After It", icon="FILE_REFRESH").action = "RENAME"
            return
        if mlo is not None:
            text(layout, context, "This interior isn't on a collision: it's placed from Blender's origin.", icon="INFO")
            return
        layout.separator()
        layout.label(text="New interior")
        if collision is None:
            text(layout, context, "Make the collision first (step 2): the interior is made on it.", icon="INFO")
            return
        layout.prop(guide, "name")
        if guide.name:
            layout.label(text=f"It will be: {game_name(guide.name)}.ytyp and .ybn", icon="FILE")
        row = layout.row()
        row.scale_y = 1.4
        row.enabled = bool(game_name(guide.name))
        row.operator(REDFORGE_OT_guide_mlo_create.bl_idname, icon="ADD")


class Rooms(Step):
    label = "Rooms"
    intro = ("The interior's spaces. Each is a box: what's inside it is drawn when the player is in the room, "
             "or sees it through a portal. limbo is the outside.")

    def status(self, context, guide):
        mlo = mlo_of(context)
        if mlo is None:
            return TODO, ""
        rooms = rooms_of(mlo)
        if not rooms:
            return TODO, "none yet"
        boxless = sum(1 for room in rooms if not has_bounds(room))
        return (PROBLEM, f"{boxless} without box") if boxless else (DONE, f"{len(rooms)} room(s)")

    def draw(self, layout, context, guide):
        if needs_mlo(layout, context):
            return
        mlo = mlo_of(context)
        active = mlo.rooms.active_index
        col = layout.column(align=True)
        for index, room in enumerate(mlo.rooms):
            row = col.row(align=True)
            left = row.row(align=True)
            left.alignment = "LEFT"
            wrong = not is_limbo(room) and not has_bounds(room)
            op = left.operator(REDFORGE_OT_guide_mlo_select.bl_idname, text=room.name, icon="ERROR" if wrong else "CHECKMARK",
                               emboss=index == active, depress=index == active)
            op.kind, op.index = "rooms", index
            right = row.row()
            right.alignment = "RIGHT"
            count = sum(1 for entity in mlo.entities if entity.attached_room_id == str(room.id))
            right.label(text="the outside" if is_limbo(room) else ("no box" if wrong else f"{count} inside"))

        room = mlo.selected_room
        if room is not None and len(mlo.rooms) and not is_limbo(room):
            box = layout.box()
            box.prop(room, "name")
            box.prop(room, "timecycle", text="Lighting")
            if room.timecycle in NOT_RDR_TIMECYCLES or not room.timecycle:
                text(box, context, "That isn't one of RDR2's timecycle modifiers: the room would have no lighting of its own.", icon="ERROR")
            text(box, context, "A timecycle modifier of the game: its interiors each have their own, named after them "
                 "(val_genstore_int, arm_sheriff_int, abe_farmhouse_int...).")
            box.operator(REDFORGE_OT_guide_mlo_room.bl_idname, text="Box Around the Selected Objects", icon="SHADING_BBOX").action = "BOUNDS"
            box.operator("sollumz.deleteroom", text="Delete the Room", icon="TRASH")

        row = layout.row()
        row.scale_y = 1.4
        row.operator(REDFORGE_OT_guide_mlo_room.bl_idname, text="Add a Room", icon="ADD").action = "ADD"
        text(layout, context, "Select what's in the room first (its walls, floor and ceiling at least): the new room's box goes around it.")
        layout.prop(context.scene, "show_room_gizmo", text="Show the Selected Room's Box")


class Portals(Step):
    label = "Portals"
    intro = ("The openings: a door or window between two rooms, or between a room and the outside (limbo). "
             "A room is only seen, and lit, through its portals.")

    def status(self, context, guide):
        mlo = mlo_of(context)
        if mlo is None:
            return TODO, ""
        wrong = sum(1 for portal in mlo.portals if portal_wrong(mlo, portal))
        if wrong:
            return PROBLEM, f"{wrong} to fix"
        if not len(mlo.portals):
            return (TODO, "none yet") if rooms_of(mlo) else (OPTIONAL, "")
        return DONE, f"{len(mlo.portals)} portal(s)"

    def draw(self, layout, context, guide):
        if needs_mlo(layout, context):
            return
        mlo = mlo_of(context)
        scene = context.scene
        active = mlo.portals.active_index
        col = layout.column(align=True)
        for index, portal in enumerate(mlo.portals):
            row = col.row(align=True)
            left = row.row(align=True)
            left.alignment = "LEFT"
            wrong = portal_wrong(mlo, portal)
            op = left.operator(REDFORGE_OT_guide_mlo_select.bl_idname, text=portal_label(mlo, index, portal),
                               icon="ERROR" if wrong else "CHECKMARK", emboss=index == active, depress=index == active)
            op.kind, op.index = "portals", index
            right = row.row()
            right.alignment = "RIGHT"
            right.label(text=wrong)

        portal = mlo.selected_portal
        if portal is not None and len(mlo.portals):
            box = layout.box()
            box.prop(portal, "room_from_id", text="From")
            box.prop(portal, "room_to_id", text="To")
            wrong = portal_wrong(mlo, portal)
            if wrong in ("limbo is From", "arrow points back"):
                text(box, context, "limbo is the outside: it's always To, the room is From." if wrong == "limbo is From"
                     else "Its arrow points into the From room: it has to point at To.", icon="ERROR")
                box.operator(REDFORGE_OT_guide_mlo_portal.bl_idname, text="Set It Right", icon="CHECKMARK").action = "RIGHT"
            elif portal_facing(mlo, portal):
                box.label(text="Its arrow points from From to To", icon="CHECKMARK")
            row = box.row(align=True)
            row.operator("sollumz.flipportal", text="Flip", icon="ARROW_LEFTRIGHT")
            row.operator("sollumz.deleteportal", text="Delete", icon="TRASH")
            if context.mode == "EDIT_MESH":
                box.operator("sollumz.updateportalfromselection", text="Move to the 4 Selected Vertices")

        layout.separator()
        layout.label(text="New portal", icon="ADD")
        if len(mlo.rooms) < 2:
            text(layout, context, "Make a room first (step 4).", icon="INFO")
            return
        rules = layout.box()
        rules.label(text="From and To", icon="INFO")
        text(rules, context, "From: the room the opening is in.")
        text(rules, context, "To: what's on its other side. For a door or window to the outside, that's limbo.")
        text(rules, context, "limbo is always To, never From. Between two rooms, either one can be From.")
        text(rules, context, "The portal's arrow points from From to To. The Guide turns it for you, and swaps the two if limbo is From.")
        layout.prop(scene, "sollumz_add_portal_room_from", text="From")
        layout.prop(scene, "sollumz_add_portal_room_to", text="To")
        col = layout.column(align=True)
        col.scale_y = 1.2
        if context.mode == "EDIT_MESH":
            col.operator(REDFORGE_OT_guide_mlo_portal.bl_idname, text="At the 4 Selected Vertices", icon="VERTEXSEL").action = "VERTS"
        else:
            col.operator(REDFORGE_OT_guide_mlo_portal.bl_idname, text="At the Selected Plane", icon="MESH_PLANE").action = "PLANE"
        text(layout, context, "A plane with 4 vertices placed in the opening, selected; or, in Edit Mode, the opening's 4 corners selected.")
        layout.prop(scene, "show_portal_gizmo", text="Show the Portals")


class Entities(Step):
    label = "Entities"
    intro = ("What's in the interior: each model, in the room it's drawn with. The shell goes in limbo. A door or "
             "window that fills a portal goes in the portal instead.")

    def status(self, context, guide):
        mlo = mlo_of(context)
        if mlo is None:
            return TODO, ""
        if not len(mlo.entities):
            return TODO, "none yet"
        loose = sum(1 for entity in mlo.entities if unplaced(entity))
        if loose:
            return PROBLEM, f"{loose} without room"
        if shell_misplaced(context, mlo) is not None:
            return PROBLEM, "shell not in limbo"
        missing = without_archetype(context, mlo)
        return (PROBLEM, f"{len(missing)} no archetype") if missing else (DONE, f"{len(mlo.entities)} inside")

    def draw(self, layout, context, guide):
        if needs_mlo(layout, context):
            return
        mlo = mlo_of(context)
        scene = context.scene
        inside = {entity.linked_object for entity in mlo.entities}
        outside = [obj for obj in parts(context) if obj not in inside]
        layout.label(text=f"{len(mlo.entities)} in the interior, {len(outside)} model(s) not in it")
        row = layout.row(align=True)
        sub = row.row(align=True)
        sub.enabled = bool(outside)
        sub.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Add All Models", icon="ADD").action = "ALL"
        sub = row.row(align=True)
        sub.enabled = any(obj in outside for obj in context.selected_objects)
        sub.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Add Selected").action = "SELECTED"

        if len(mlo.entities):
            col = layout.column(align=True)
            for room in mlo.rooms:
                count = sum(1 for entity in mlo.entities if entity.attached_room_id == str(room.id))
                row = col.row()
                row.label(text=room.name, icon="CHECKMARK" if count else "RADIOBUT_OFF")
                sub = row.row()
                sub.alignment = "RIGHT"
                sub.label(text=str(count))
            in_portals = sum(1 for entity in mlo.entities if entity.attached_portal_id != "-1")
            if in_portals:
                row = col.row()
                row.label(text="in a portal", icon="CHECKMARK")
                sub = row.row()
                sub.alignment = "RIGHT"
                sub.label(text=str(in_portals))
            loose = sum(1 for entity in mlo.entities if unplaced(entity))
            if loose:
                row = col.row()
                row.label(text="without room", icon="ERROR")
                row.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text=f"Select {loose}").action = "SELECT_LOOSE"
            layout.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Sort into Rooms by Position", icon="SORTSIZE").action = "SORT"

            chosen = [entity for entity in mlo.entities if entity.linked_object in context.selected_objects]
            box = layout.box()
            if not chosen:
                text(box, context, "Select objects of the interior to move them to a room or portal.", icon="INFO")
            else:
                box.label(text=f"{len(chosen)} selected", icon="RESTRICT_SELECT_OFF")
                box.prop(scene, "sollumz_add_entity_room", text="Room")
                box.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Put in This Room").action = "ROOM"
                if len(mlo.portals):
                    box.prop(scene, "sollumz_add_entity_portal", text="Portal")
                    box.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Put in This Portal").action = "PORTAL"
                box.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Take Out of the Interior", icon="X").action = "REMOVE"

        if shell_misplaced(context, mlo) is not None:
            text(layout, context, "The shell goes in limbo, not in a room: it's what is seen of the building from every room and from outside.", icon="ERROR")
            layout.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Put the Shell in limbo", icon="CHECKMARK").action = "SHELL"
        missing = without_archetype(context, mlo)
        if missing:
            text(layout, context, f"{len(missing)} model(s) have no archetype of their own: the game wouldn't know what they are.", icon="ERROR")
            layout.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Create Their Archetypes", icon="ADD").action = "ARCHETYPES"


class Export(Step):
    label = "Check & Export"
    intro = "What's left to fix, then the files: every model, the collision, the textures and the .ytyp, to a folder or into RedForge's project."

    def issues(self, context, guide) -> list[tuple[int, str]]:
        issues = []
        for index, step in enumerate(MloFlow.steps[:-1]):
            state, note = step.status(context, guide)
            if state in (PROBLEM, TODO):
                issues.append((index, f"{step.label}: {note}" if note else f"{step.label}: not done"))
        return issues

    def status(self, context, guide):
        mlo = mlo_of(context)
        count = len(self.issues(context, guide)) + (len(off_the_games(mlo)) if mlo is not None else 0)
        return (PROBLEM, f"{count} to fix") if count else (TODO, "ready")

    def draw(self, layout, context, guide):
        mlo = mlo_of(context)
        issues = self.issues(context, guide)
        for index, what in issues:
            row = layout.row()
            text(row, context, what, icon="ERROR")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.operator(core.REDFORGE_OT_guide_step.bl_idname, text="Fix").index = index
        if mlo is None:
            return
        off = off_the_games(mlo)
        for what in off:
            text(layout, context, what, icon="ERROR")
        if off:
            layout.operator(REDFORGE_OT_guide_mlo_entities.bl_idname, text="Give Them the Game's Values", icon="CHECKMARK").action = "GAME"
        if not issues and not off:
            layout.label(text="Nothing to fix", icon="CHECKMARK")
        from ..redforge import link
        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.enabled = bool(len(mlo.entities))
        row = col.row(align=True)
        row.enabled = link.connected()
        row.operator(REDFORGE_OT_guide_mlo_send.bl_idname, icon="EXPORT")
        col.operator(REDFORGE_OT_guide_mlo_export.bl_idname, icon="FILE_FOLDER")
        if not link.connected():
            layout.label(text="RedForge isn't running", icon="UNLINKED")
        layout.prop(context.scene, "sollumz_export_path", text="Folder")
        text(layout, context, f"In RedForge, place {mlo.name} on the map like any other object: it's the interior.")


@flow
class MloFlow(Flow):
    id = "mlo"
    label = "Interior (MLO)"
    icon = "MOD_BUILD"
    summary = "An interior: a building's inside, with rooms and portals. From its models to the .ytyp and every file"
    steps = (Shell(), Collision(), Interior(), Rooms(), Portals(), Entities(), Export())

    def adopt(self, context):
        return selected_mlo(context)

    def begin(self, context, guide, adopted):
        guide.target = None
        if adopted is not None:
            guide.mlo = adopted.uuid
        elif find_mlo(context, guide.mlo) is None:  # (none yet, or the one from before is gone)
            selected = selected_mlo(context)
            guide.mlo = selected.uuid if selected is not None else ""

    def subject(self, context, guide) -> str:
        mlo = mlo_of(context)
        return mlo.name if mlo is not None else ""


# ---- operators


class MloOperator:
    """An operator on the Guide's interior."""
    bl_options = {"UNDO", "INTERNAL"}
    needs_interior = True

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        mlo = mlo_of(context)
        if mlo is not None:
            mlo = select_mlo(context, mlo.uuid)  # (what the operators and the lists of rooms go by)
        try:
            if mlo is None and self.needs_interior:
                raise RuntimeError("There's no interior: make it in step 3")
            message = self.run(context, context.scene.rf_guide, mlo)
        except Exception as ex:
            self.report({"ERROR"}, str(ex))
            return {"CANCELLED"}
        if message:
            self.report({"INFO"}, message)
        for area in context.screen.areas if context.screen else ():  # (the rooms' and portals' gizmos)
            area.tag_redraw()
        return {"FINISHED"}


def convert_materials(obj) -> list[str]:
    """Makes game shaders of the drawable's materials; the names of the ones it couldn't."""
    failed = []
    for material, model in materials_of(obj)[0].items():
        if material.sollum_type == MaterialType.SHADER:
            continue
        try:
            if MaterialConverter(model, material).auto_convert() is None:
                failed.append(material.name)
        except Exception as ex:
            print(f"RedForge Guide: {material.name}: {ex}")
            failed.append(material.name)
    fix_mesh_data(obj)
    return failed


class REDFORGE_OT_guide_mlo_make_models(MloOperator, bpy.types.Operator):
    """Make a game model of each selected mesh, named after it, with its materials made game shaders"""
    bl_idname = "redforge.guide_mlo_make_models"
    bl_label = "Make Models"
    needs_interior = False

    def run(self, context, guide, mlo):
        meshes = plain_meshes(context)
        game = context.scene.sollum_game_type
        made, failed = [], []
        for obj in meshes:
            name = game_name(obj.name)
            with context.temp_override(collection=obj.users_collection[0]):
                drawable = convert_obj_to_drawable(obj, game)
            obj.name = f"{name}.model"
            drawable.name = name
            failed += convert_materials(drawable)
            made.append(drawable)
        select_only(context, made)
        if failed:
            raise RuntimeError(f"{len(made)} model(s) made, but these materials couldn't be converted: {', '.join(failed)}")
        return f"{len(made)} model(s) made"


class REDFORGE_OT_guide_mlo_fix_models(MloOperator, bpy.types.Operator):
    """Make game shaders of the models' materials, picked from what each has"""
    bl_idname = "redforge.guide_mlo_fix_models"
    bl_label = "Convert Their Materials"
    needs_interior = False

    def run(self, context, guide, mlo):
        failed = [name for obj in parts_to_fix(context) for name in convert_materials(obj)]
        left = parts_to_fix(context)
        if left:
            select_only(context, left)
            raise RuntimeError(f"{len(left)} model(s) still need a look, with Model (YDR): {', '.join(o.name for o in left[:5])}"
                               + (f" ({', '.join(failed[:5])} couldn't be converted)" if failed else " (a mesh has no material)"))
        return "Materials converted"


class REDFORGE_OT_guide_mlo_shell(MloOperator, bpy.types.Operator):
    """The interior's shell"""
    bl_idname = "redforge.guide_mlo_shell"
    bl_label = "Make the Shell"
    needs_interior = False
    action: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {
            "MAKE": "Make one static model of the selected meshes, named as above, with their materials made game shaders",
            "USE": "The selected model is the interior's shell",
            "NEW": "Leave this interior as it is and start another one from its shell",
            "RENAME": "Give the collision the interior's name: its .ybn is found by it",
        }.get(properties.action, "")

    def run(self, context, guide, mlo):
        if self.action == "NEW":
            guide.shell = guide.collision = None
            guide.mlo = ""
            guide.name = ""
            guide.step = 0
            select_only(context, [])
            return ""
        if self.action == "RENAME":
            mlo.asset.name = game_name(mlo.name)
            mlo.asset_name = mlo.physics_dictionary = mlo.asset.name
            return f"The collision is {mlo.asset.name}"
        if self.action == "USE":
            models = selected_models(context)
            if len(models) != 1:
                raise RuntimeError("Select the one model that is the shell")
            guide.shell = models[0]
            guide.step = 1
            return f"{guide.shell.name} is the shell"
        meshes = plain_meshes(context)
        if not meshes:
            raise RuntimeError("Select the shell's meshes")
        first = context.active_object if context.active_object in meshes else meshes[0]
        name = game_name(guide.name or first.name)
        game = context.scene.sollum_game_type
        with context.temp_override(collection=first.users_collection[0]):
            shell = convert_obj_to_drawable(first, game) if len(meshes) == 1 else convert_objs_to_single_drawable(meshes, game)
        models = models_of(shell)
        for index, model in enumerate(models):
            model.name = f"{name}.model" if len(models) == 1 else f"{name}.model{index + 1}"
        shell.name = name
        failed = convert_materials(shell)
        guide.shell = shell
        guide.name = ""
        guide.step = 1
        select_only(context, [shell])
        if failed:
            raise RuntimeError(f"{name} is the shell, but these materials couldn't be converted: {', '.join(failed)}")
        return f"{name} is the shell"


class REDFORGE_OT_guide_mlo_collision(MloOperator, bpy.types.Operator):
    """The interior's collision"""
    bl_idname = "redforge.guide_mlo_collision"
    bl_label = "Collision"
    needs_interior = False
    source: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {
            "SHELL": "Make the collision of copies of the shell's meshes, as an object of its own. The shell isn't changed",
            "SELECTED": "Make the collision of the selected meshes, ones made for it: simpler than the shell",
            "ADD": "Make the selected meshes part of the collision",
            "MATERIAL": "Give the collision the material picked in the list",
            "REMOVE": "Delete the collision",
        }.get(properties.source, "")

    def run(self, context, guide, mlo):
        game = context.scene.sollum_game_type
        wm = context.window_manager
        collision = collision_of(context, guide)
        if self.source == "REMOVE":
            for obj in (collision, *collision.children_recursive):
                bpy.data.objects.remove(obj, do_unlink=True)
            return "Collision removed"
        if self.source == "MATERIAL":
            meshes = collision_meshes_of(collision)
        else:
            if self.source == "SHELL":
                shell = shell_of(context, guide)
                set_all_lods(shell, LODLevel.HIGH)
                meshes = [duplicate_object(model) for model in models_of(shell)]
                for obj in meshes:  # (their own mesh: the shell's keeps its materials)
                    obj.data = obj.data.copy()
            else:
                meshes = plain_meshes(context)
            if not meshes:
                raise RuntimeError("No mesh to make the collision of")
            worlds = [obj.matrix_world.copy() for obj in meshes]
            with context.temp_override(collection=meshes[0].users_collection[0]):
                if collision is None:
                    collision = convert_objs_to_single_composite(meshes, SollumType.BOUND_GEOMETRYBVH, game, wm.sz_flag_preset_index)
                    collision.name = f"{shell_of(context, guide).name}_col" if shell_of(context, guide) is not None else "interior_col"
                    collision.parent = None
                    guide.collision = collision
                else:
                    for obj in meshes:
                        convert_obj_to_bvh(obj, game, wm.sz_flag_preset_index).parent = collision
            context.view_layer.update()
            for obj in meshes:  # (each under the collision's origin, then where it was, whatever it was parented to)
                obj.parent.matrix_world = collision.matrix_world
            context.view_layer.update()
            for obj, world in zip(meshes, worlds):
                obj.matrix_world = world
        for obj in meshes:
            obj.data.materials.clear()
            obj.data.materials.append(create_collision_material_from_index(wm.sz_collision_material_index, game))
            if self.source != "MATERIAL":
                from .ybn import set_kind
                set_kind(obj.parent, "solid")  # (whatever flag preset was last picked in the Expert Tools)
        guide.collision_material_shown = False
        if self.source in ("SHELL", "SELECTED"):
            guide.step = 2
        select_only(context, [collision])
        return "Collision material set" if self.source == "MATERIAL" else f"{collision.name}: {len(collision_meshes_of(collision))} mesh(es)"


class REDFORGE_OT_guide_mlo_create(MloOperator, bpy.types.Operator):
    """Make the interior on the collision: a ytyp named after it with its MLO archetype, the collision named after it too, and the room that stands for the outside"""
    bl_idname = "redforge.guide_mlo_create"
    bl_label = "Create the Interior"
    needs_interior = False

    def run(self, context, guide, mlo):
        scene = context.scene
        name = game_name(guide.name)
        if not name:
            raise RuntimeError("The interior needs a name")
        collision = guide.collision
        if collision is None or collision.name not in scene.objects:
            raise RuntimeError("Make the collision first (step 2)")
        collision.name = name  # (the .ybn the game finds the interior's collision in)
        bpy.ops.sollumz.createytyp()
        ytyp = get_selected_ytyp(context)
        ytyp.name = name
        # The archetype, the way it's made by hand from a selected collision: named after it, with it as its asset.
        before = scene.create_archetype_type
        scene.create_archetype_type = ArchetypeType.MLO
        try:
            select_only(context, [collision])
            bpy.ops.sollumz.createarchetypefromselected()
        finally:
            scene.create_archetype_type = before
        archetype = ytyp.selected_archetype
        if archetype is None or archetype.type != ArchetypeType.MLO or archetype.asset != collision:
            raise RuntimeError("The interior wasn't made")
        archetype.name = name
        limbo = archetype.new_room()
        limbo.name = LIMBO
        limbo.timecycle = ""
        limbo.flags.total = ROOM_FLAGS
        refresh_limbo(archetype)
        guide.mlo = archetype.uuid
        guide.name = ""
        guide.step = 3
        return f"{name} is an interior, in {name}.ytyp, on its collision"


class REDFORGE_OT_guide_mlo_use(bpy.types.Operator):
    """Work on this interior"""
    bl_idname = "redforge.guide_mlo_use"
    bl_label = "Work on This Interior"
    bl_options = {"INTERNAL"}
    ytyp: IntProperty()
    archetype: IntProperty()

    def execute(self, context):
        context.scene.ytyp_index = self.ytyp
        context.scene.ytyps[self.ytyp].archetypes.select(self.archetype)
        context.scene.rf_guide.mlo = context.scene.ytyps[self.ytyp].archetypes[self.archetype].uuid
        return {"FINISHED"}


class REDFORGE_OT_guide_mlo_select(bpy.types.Operator):
    """Select it, to change it"""
    bl_idname = "redforge.guide_mlo_select"
    bl_label = "Select"
    bl_options = {"INTERNAL"}
    kind: StringProperty()
    index: IntProperty()

    def execute(self, context):
        mlo = mlo_of(context)
        if mlo is None:
            return {"CANCELLED"}
        mlo = select_mlo(context, mlo.uuid)
        getattr(mlo, self.kind).select(self.index)
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}


class REDFORGE_OT_guide_mlo_room(MloOperator, bpy.types.Operator):
    """A room of the interior, with its box around the selected objects"""
    bl_idname = "redforge.guide_mlo_room"
    bl_label = "Room"
    action: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {"ADD": "Add a room, its box around the selected objects",
                "BOUNDS": "Put the selected room's box around the selected objects"}.get(properties.action, "")

    def run(self, context, guide, mlo):
        bounds = bounds_of_objects(context.selected_objects, origin_inverse(mlo))
        if self.action == "ADD":
            room = mlo.new_room()
            room.name = f"room_{len(rooms_of(mlo))}"
            room.flags.total = ROOM_FLAGS
            room.timecycle = TIMECYCLE
        else:
            room = mlo.selected_room
            if room is None or is_limbo(room):
                raise RuntimeError("Select a room in the list")
            if bounds is None:
                raise RuntimeError("Select the objects the room's box goes around")
        if bounds is not None:
            room.bb_min, room.bb_max = bounds
        refresh_limbo(mlo)
        if bounds is None:
            return f"{room.name} added without a box: select what's in it, then Box Around the Selected Objects"
        size = bounds[1] - bounds[0]
        return f"{room.name}: {size.x:.1f} x {size.y:.1f} x {size.z:.1f} m"


class REDFORGE_OT_guide_mlo_portal(MloOperator, bpy.types.Operator):
    """A portal of the interior"""
    bl_idname = "redforge.guide_mlo_portal"
    bl_label = "Portal"
    action: StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode in ("OBJECT", "EDIT_MESH")

    @classmethod
    def description(cls, context, properties):
        return {
            "PLANE": "Make a portal of each selected plane: a mesh with 4 vertices, placed in the opening. The plane itself "
                     "isn't part of the interior, and can be deleted afterwards. The portal is turned to face To",
            "VERTS": "Make a portal with its corners at the 4 selected vertices, turned to face To",
            "RIGHT": "Put the selected portal's From and To the way the game has them: limbo as To, its arrow from From to To",
        }.get(properties.action, "")

    def run(self, context, guide, mlo):
        scene = context.scene
        if self.action == "RIGHT":
            portal = mlo.selected_portal
            changed = set_right(mlo, portal)
            message = ", ".join(changed)
            return message[0].upper() + message[1:] if changed else "It was right already"
        if "-1" in (scene.sollumz_add_portal_room_from, scene.sollumz_add_portal_room_to):
            raise RuntimeError("Choose the rooms on the portal's two sides, From and To")
        if scene.sollumz_add_portal_room_from == scene.sollumz_add_portal_room_to:
            raise RuntimeError("From and To are the same room: a portal is between two")
        made = []
        if self.action == "VERTS":
            count = len(mlo.portals)
            bpy.ops.sollumz.createportalfromselection()  # (its corners in order around the opening, as seen in the view)
            made = [mlo.portals[i] for i in range(count, len(mlo.portals))]
            if not made:
                raise RuntimeError("Select exactly the 4 vertices at the opening's corners")
        else:
            planes = [obj for obj in context.selected_objects if obj.type == "MESH" and len(obj.data.vertices) == 4]
            if not planes:
                raise RuntimeError("Select a plane (a mesh with 4 vertices) placed in the opening")
            matrix = origin_inverse(mlo)
            count = len(mlo.portals)
            for plane in planes:
                mesh = plane.data
                order = list(mesh.polygons[0].vertices) if len(mesh.polygons) == 1 else range(4)  # (around the face)
                portal = mlo.new_portal()
                portal.corner1, portal.corner2, portal.corner3, portal.corner4 = (
                    matrix @ plane.matrix_world @ mesh.vertices[i].co for i in order)
                portal.room_from_id = scene.sollumz_add_portal_room_from
                portal.room_to_id = scene.sollumz_add_portal_room_to
            made = [mlo.portals[i] for i in range(count, len(mlo.portals))]  # (not kept while the list grows)
        changed = sorted({what for portal in made for what in set_right(mlo, portal)})
        return f"{len(made)} portal(s) made" + (f": {', '.join(changed)}" if changed else "")


class REDFORGE_OT_guide_mlo_entities(MloOperator, bpy.types.Operator):
    """The interior's entities"""
    bl_idname = "redforge.guide_mlo_entities"
    bl_label = "Entities"
    action: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {
            "ALL": "Put every model of the scene in the interior: the shell in limbo, each other one in the room its centre is in",
            "SELECTED": "Put the selected models in the interior: the shell in limbo, each other one in the room its centre is in",
            "SORT": "Put every entity that has no room or portal in the room its centre is in",
            "SELECT_LOOSE": "Select the objects that have no room or portal",
            "ROOM": "Put the selected objects in the room chosen above",
            "PORTAL": "Put the selected objects in the portal chosen above: for a door or window that fills it",
            "REMOVE": "The selected objects stop being part of the interior (they aren't deleted)",
            "ARCHETYPES": "Make an archetype, in the interior's ytyp, for each of its models that has none",
            "SHELL": "Put the shell in limbo, as the game's interiors have it",
            "GAME": "Give the rooms and entities that have none the flags the game's interiors have, and the rooms "
                    "with a timecycle that isn't in RDR2 one that is",
        }.get(properties.action, "")

    def sort(self, mlo, entities) -> int:
        """Each entity in the room its object's centre is in. How many found one."""
        matrix = origin_inverse(mlo)
        rooms = [room for room in rooms_of(mlo) if has_bounds(room)]
        shell = shell_of(bpy.context, bpy.context.scene.rf_guide)
        limbo = next((room for room in mlo.rooms if is_limbo(room)), None)
        placed = 0
        for entity in entities:
            if shell is not None and limbo is not None and entity.linked_object == shell:
                entity.attached_room_id = str(limbo.id)  # (the shell: in limbo, wherever its centre is)
                placed += 1
                continue
            bounds = bounds_of_objects([entity.linked_object], matrix) if entity.linked_object is not None else None
            centre = (bounds[0] + bounds[1]) * 0.5 if bounds is not None else Vector(entity.position)
            room = next((r for r in rooms if all(r.bb_min[i] <= centre[i] <= r.bb_max[i] for i in range(3))), None)
            if room is not None:
                entity.attached_room_id = str(room.id)
                placed += 1
        return placed

    def run(self, context, guide, mlo):
        scene = context.scene
        action = self.action
        if action in ("ALL", "SELECTED"):
            inside = {entity.linked_object for entity in mlo.entities}
            objects = [obj for obj in parts(context) if obj not in inside and (action == "ALL" or obj.select_get())]
            first = len(mlo.entities)
            for obj in objects:
                entity = mlo.new_entity()
                entity.archetype_name = game_name(obj.name)
                entity.linked_object = obj
                entity.flags.total = ENTITY_FLAGS
            # (taken from the list once it's whole: an entity kept while others are added is left dangling when the
            # list grows, and Blender crashes on it)
            added = list(mlo.entities)[first:]
            placed = self.sort(mlo, added)
            return f"{len(added)} added, {placed} of them in a room"
        if action == "SORT":
            loose = [entity for entity in mlo.entities if unplaced(entity)]
            return f"{self.sort(mlo, loose)} of {len(loose)} found their room"
        if action == "GAME":
            set_the_games(mlo)
            return "Rooms and entities have the game's values"
        if action == "SHELL":
            entity = shell_misplaced(context, mlo)
            if entity is not None:
                entity.attached_room_id = next(str(room.id) for room in mlo.rooms if is_limbo(room))
                entity.attached_portal_id = "-1"
            return "The shell is in limbo"
        if action == "SELECT_LOOSE":
            select_only(context, [e.linked_object for e in mlo.entities if unplaced(e) and e.linked_object is not None])
            return ""
        if action == "ARCHETYPES":
            missing = without_archetype(context, mlo)
            ytyp = get_selected_ytyp(context)
            uuid = mlo.uuid
            before = scene.create_archetype_type
            scene.create_archetype_type = ArchetypeType.BASE
            try:
                select_only(context, missing)
                bpy.ops.sollumz.createarchetypefromselected()
            finally:
                scene.create_archetype_type = before
                # (a new archetype is the selected one: back to the interior, which is found again as the list grew)
                select_mlo(context, uuid)
            return f"{len(missing)} archetype(s) made in {ytyp.name}.ytyp"
        chosen = [i for i, entity in enumerate(mlo.entities) if entity.linked_object in context.selected_objects]
        if not chosen:
            raise RuntimeError("Select objects that are in the interior")
        if action == "ROOM":
            for i in chosen:
                mlo.entities[i].attached_room_id = scene.sollumz_add_entity_room
                mlo.entities[i].attached_portal_id = "-1"
        elif action == "PORTAL":
            for i in chosen:
                mlo.entities[i].attached_portal_id = scene.sollumz_add_entity_portal
                mlo.entities[i].attached_room_id = "-1"
        elif action == "REMOVE":
            for i in sorted(chosen, reverse=True):
                mlo.entities.remove(i)
            mlo.entities.select(0)
        return f"{len(chosen)} object(s)"


def prepare(context, mlo):
    """Before the files are written: the entities named after their models, the outside's box around the rooms. Returns
    the models, and the ytyps to write (the interior's, and the ones with its models' archetypes)."""
    for entity in mlo.entities:
        if entity.linked_object is not None:
            entity.archetype_name = game_name(entity.linked_object.name)
    refresh_limbo(mlo)
    room_the_collision(mlo)
    models = list(dict.fromkeys(entity.linked_object for entity in mlo.entities if entity.linked_object is not None))
    ytyps = [get_selected_ytyp(context).name]
    for obj in models:
        ytyp, _ = archetype_of(context, obj)
        if ytyp is not None and ytyp.name not in ytyps:
            ytyps.append(ytyp.name)
    return models, ytyps


def collision_to_send(mlo):
    asset = mlo.asset
    return asset if (asset is not None and asset.sollum_type == SollumType.BOUND_COMPOSITE) else None


# A collision face just outside a portal to the outside (a porch, a doorstep, a walkway into a cave) is the outside's:
# in front of the portal by up to this far, and no further to its sides than this.
OUTSIDE_DEPTH = 6.0
OUTSIDE_MARGIN = 1.0


def ways_outside(mlo):
    """The portals to the outside, each as (centre, the direction out of the interior, the opening's two directions,
    half its size along each), in the interior's space."""
    limbo = next((str(room.id) for room in mlo.rooms if is_limbo(room)), None)
    found = []
    for portal in mlo.portals:
        if limbo is None or limbo not in (portal.room_from_id, portal.room_to_id) or portal.room_from_id == portal.room_to_id:
            continue
        corners = [Vector(c) for c in (portal.corner1, portal.corner2, portal.corner3, portal.corner4)]
        out = (corners[1] - corners[0]).cross(corners[2] - corners[0])  # (the arrow: it points to To)
        across = corners[1] - corners[0]
        if out.length < 1e-6 or across.length < 1e-6:
            continue
        out.normalize()
        across.normalize()
        if portal_facing(mlo, portal) is False:
            out = -out
        if portal.room_from_id == limbo:
            out = -out
        up = out.cross(across)
        centre = sum(corners, Vector()) / 4
        found.append((centre, out, across, up, max(abs((c - centre).dot(across)) for c in corners),
                      max(abs((c - centre).dot(up)) for c in corners)))
    return found


def room_the_collision(mlo) -> int:
    """Gives the collision what tells the game which room is stood in: each face's material carries its room's number
    (the room's place in the list, limbo being 0). Without it the game takes whoever walks in to be outside, and stops
    drawing the interior around them. A face just outside a portal to the outside is the outside's (or whoever stands
    on the porch is taken to be inside, and sees the world only through the door). Any other face is of the room its
    centre is in, or the nearest one; with one room, that room's. A material used in two rooms is copied for the second. The game's interior collisions also
    have 64 in a bound's unnamed field, a mass of 1, and the composite's mass the number of its parts: given where
    there's none. Returns how many faces changed room."""
    collision = collision_to_send(mlo)
    if collision is None:
        return 0
    bounds = [obj for obj in collision.children_recursive if obj.sollum_type in BOUND_TYPES]
    for obj in bounds:
        if obj.bound_properties.unk_11h == 0:
            obj.bound_properties.unk_11h = 64
        if obj.bound_properties.mass == 0:
            obj.bound_properties.mass = 1
    if collision.bound_properties.mass == 0:
        collision.bound_properties.mass = len(bounds)
    rooms = [(index, room) for index, room in enumerate(mlo.rooms) if not is_limbo(room) and has_bounds(room)]
    if not rooms:
        return 0

    ways_out = ways_outside(mlo)

    def room_at(point) -> int:
        for centre, out, across, up, half_across, half_up in ways_out:
            offset = point - centre
            if (0.05 < offset.dot(out) <= OUTSIDE_DEPTH and abs(offset.dot(across)) <= half_across + OUTSIDE_MARGIN
                    and abs(offset.dot(up)) <= half_up + OUTSIDE_MARGIN):
                return 0
        if len(rooms) == 1:
            return rooms[0][0]
        # (how far outside each room's box the point is: 0 inside it)
        return min(rooms, key=lambda r: sum(max(r[1].bb_min[i] - point[i], 0.0, point[i] - r[1].bb_max[i]) ** 2
                                            for i in range(3)))[0]

    matrix = origin_inverse(mlo)
    copies = {}  # (the material it was copied from, room) -> the copy, shared by the collision's meshes
    changed = 0
    for obj in collision_meshes_of(collision):
        mesh = obj.data
        to_interior = matrix @ obj.matrix_world
        old = list(mesh.materials)
        new, slots, faces = [], {}, []
        for polygon in mesh.polygons:
            material = old[polygon.material_index] if polygon.material_index < len(old) else None
            if material is None:
                faces.append(None)
                continue
            room = room_at(to_interior @ polygon.center)
            if material.collision_properties.room_id != room:
                changed += 1
                # (its own material when no other face of it stays in the room it has: nothing to copy)
                if (material, room) not in copies:
                    copies[(material, room)] = material.copy()
                    copies[(material, room)].collision_properties.room_id = room
                material = copies[(material, room)]
            if material not in slots:
                slots[material] = len(new)
                new.append(material)
            faces.append(slots[material])
        if new == old:
            continue
        mesh.materials.clear()
        for material in new:
            mesh.materials.append(material)
        for polygon, slot in zip(mesh.polygons, faces):
            if slot is not None:
                polygon.material_index = slot
    return changed


class REDFORGE_OT_guide_mlo_export(MloOperator, bpy.types.Operator):
    """Write in the folder every model of the interior, the textures that aren't in the models' files, and the ytyps"""
    bl_idname = "redforge.guide_mlo_export"
    bl_label = "Export to the Folder"
    bl_options = {"INTERNAL"}

    def run(self, context, guide, mlo):
        scene = context.scene
        folder = bpy.path.abspath(scene.sollumz_export_path)
        if not scene.sollumz_export_path or not os.path.isdir(folder):
            raise RuntimeError("Choose the folder to export to")
        models, ytyps = prepare(context, mlo)
        settings = get_export_settings(context)
        wanted = {"limit_to_selected": True, "export_with_ytyp": False}
        before = {name: getattr(settings, name) for name in wanted}
        changed = [name for name in wanted if before[name] != wanted[name]]
        ytds = [ytd for obj in models if obj.sollum_type == SollumType.DRAWABLE
                for ytd in [write_ytd(context, obj, folder)] if ytd is not None]
        collision = collision_to_send(mlo)
        select_only(context, models + ([collision] if collision is not None else []))
        index = scene.ytyp_index
        try:
            for name in changed:
                setattr(settings, name, wanted[name])
            if "FINISHED" not in bpy.ops.sollumz.export_assets(directory=folder, direct_export=True):
                raise RuntimeError("The models weren't exported: see the Info log")
            from ..ytyp.ytypexport import selected_ytyp_to_xml
            for name in ytyps:
                scene.ytyp_index = scene.ytyps.find(name)
                ytyp_xml = selected_ytyp_to_xml(settings.apply_transforms)
                ytyp_xml.write_xml(os.path.join(folder, f"{ytyp_xml.name}.ytyp.rsc.xml"))
        finally:
            scene.ytyp_index = index
            for name in changed:
                setattr(settings, name, before[name])
        return (f"Exported {len(models)} model(s), {'the collision, ' if collision is not None else ''}"
                f"{len(ytds)} texture dictionary(ies) and {', '.join(f'{n}.ytyp' for n in ytyps)}")


class REDFORGE_OT_guide_mlo_send(MloOperator, bpy.types.Operator):
    """Put the interior in RedForge's project: every model, the textures that aren't in the models' files, and the ytyps"""
    bl_idname = "redforge.guide_mlo_send"
    bl_label = "Send to RedForge"
    bl_options = {"INTERNAL"}

    def run(self, context, guide, mlo):
        from ..redforge import bridge, link
        models, ytyps = prepare(context, mlo)
        port = bridge.prefs(context).redforge_port
        staging = os.path.join(tempfile.gettempdir(), "RedForge", "Blender", "send")
        sent = []
        for obj in models:  # (the texture dictionaries first: the archetypes sent with the models name them)
            if obj.sollum_type != SollumType.DRAWABLE:
                continue
            folder = os.path.join(staging, f"{game_name(obj.name)}.ytd.textures")
            shutil.rmtree(folder, ignore_errors=True)
            ytd = write_ytd(context, obj, folder)
            if ytd is not None:
                name = os.path.basename(ytd)[:-len(".xml")]
                link.request(port, "import", xml=ytd, file=name)
                sent.append(name)
        collision = collision_to_send(mlo)
        if collision is not None:  # (not a model to RedForge's link: sent as the file it is)
            from ..ybn.ybnexport import export_ybn
            name = f"{game_name(collision.name)}.ybn"
            folder = os.path.join(staging, name)
            shutil.rmtree(folder, ignore_errors=True)
            os.makedirs(folder)
            xml = os.path.join(folder, f"{name}.xml")
            if not export_ybn(collision, xml):
                raise RuntimeError("The collision wasn't exported: see the Info log")
            link.request(port, "import", xml=xml, file=name)
            sent.append(name)
        for obj in models:
            if bridge.FILE_KEY in obj:
                bridge._changed.add(obj[bridge.FILE_KEY])  # (asked for: sent even if nothing changed since)
        select_only(context, models)
        message = bridge.send_new(context, models)
        left = [name for name in ytyps if f"{name}.ytyp" not in message]  # (the ones that didn't go with the models)
        sent += bridge.send_ytyps(context, names=left) if left else []
        return message + (", " + ", ".join(sent) if sent else "")
