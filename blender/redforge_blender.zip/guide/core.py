"""The Guide: the sidebar's main panel. Pick what to make, and it's made in steps, each with the few controls it needs.
A flow (one per kind of file, see ydr.py) is a list of steps; a step says where it stands by looking at the scene, so a
model that was imported or made by hand shows its steps as done, and any step can be opened at any time."""
import textwrap

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty, StringProperty

from ..sollumz_preferences import get_addon_preferences
from ..sollumz_properties import LODLevel, SOLLUMZ_UI_NAMES

DONE = "done"  # nothing left to do in the step
TODO = "todo"  # needed, not done yet
PROBLEM = "problem"  # something in it has to be fixed
OPTIONAL = "optional"  # can be skipped

ICONS = {DONE: "CHECKMARK", TODO: "RADIOBUT_OFF", PROBLEM: "ERROR", OPTIONAL: "RADIOBUT_OFF"}


class Step:
    label = ""
    intro = ""  # what the step is for, in a sentence or two

    def status(self, context, guide) -> tuple[str, str]:
        """Where the step stands, and a few words shown next to it in the list."""
        return TODO, ""

    def draw(self, layout, context, guide):
        ...


class Flow:
    id = ""
    label = ""
    icon = "NONE"
    summary = ""  # the button's tooltip
    steps: tuple[Step, ...] = ()

    def adopt(self, context):
        """What of this flow's kind is selected (something with a name), to carry on with it."""
        return None

    def begin(self, context, guide, adopted):
        """Starts the flow: on what was adopted, or on nothing yet."""
        guide.target = adopted

    def subject(self, context, guide) -> str:
        """The name of what the flow is working on, for the panel's title."""
        target = target_of(context, guide)
        return target.name if target is not None else ""


FLOWS: dict[str, Flow] = {}


def flow(cls):
    """Class decorator: adds the flow to the Guide's home."""
    FLOWS[cls.id] = cls()
    return cls


def target_of(context, guide):
    """The object the flow works on, unless it was deleted."""
    obj = guide.target
    return obj if (obj is not None and obj.name in context.scene.objects) else None


def first_open_step(context, guide, flow_) -> int:
    for index, step in enumerate(flow_.steps):
        if step.status(context, guide)[0] in (TODO, PROBLEM):
            return index
    return len(flow_.steps) - 1


def text(layout, context, message: str, icon: str = "NONE"):
    """A label that wraps to the sidebar's width (Blender's don't)."""
    width = context.region.width / (7.0 * context.preferences.system.ui_scale)
    col = layout.column(align=True)
    col.scale_y = 0.75
    for index, line in enumerate(textwrap.wrap(message, max(16, int(width) - (8 if icon != "NONE" else 4)))):
        col.label(text=line, icon=icon if index == 0 else ("BLANK1" if icon != "NONE" else "NONE"))
    return col


def select_only(context, objects, active=None):
    for obj in context.view_layer.objects:
        obj.select_set(False)
    for obj in objects:
        if obj.name in context.view_layer.objects:
            obj.hide_set(False)
            obj.select_set(True)
    context.view_layer.objects.active = active or (objects[0] if objects else None)


def _place(name, default):
    """A property kept on the window manager: where the Guide is isn't something Undo takes back (the scene's
    properties are), or a click on Undo after a step would also walk the Guide back."""
    def get(self):
        return getattr(bpy.context.window_manager, name, default)

    def put(self, value):
        setattr(bpy.context.window_manager, name, value)
    return {"get": get, "set": put}


class GuideState(bpy.types.PropertyGroup):
    flow: StringProperty(**_place("rf_guide_flow", ""))
    step: IntProperty(min=0, **_place("rf_guide_step", 0))
    shell: PointerProperty(type=bpy.types.Object, description="The model that is the interior's shell")
    collision: PointerProperty(type=bpy.types.Object, description="The interior's collision, until the interior is made on it")
    mlo: StringProperty(description="The interior the MLO flow works on (its archetype's uuid), whatever is selected in the ytyp list")
    target: PointerProperty(type=bpy.types.Object)
    name: StringProperty(name="Name", description="The model's name in the game: lowercase, no spaces")
    expanded: StringProperty(description="The material whose textures are shown")
    ytyp: StringProperty(name="YTYP", description="The ytyp the archetype goes in. Empty: a new one, named after the model")
    lod_levels: EnumProperty(
        name="Levels", description="The levels of detail to make from the High one", options={"ENUM_FLAG"},
        items=tuple((level.value, SOLLUMZ_UI_NAMES[level], "") for level in (LODLevel.MEDIUM, LODLevel.LOW, LODLevel.VERYLOW)),
        default={LODLevel.MEDIUM.value, LODLevel.LOW.value, LODLevel.VERYLOW.value})
    flags_shown: BoolProperty(name="Flag by Flag", description="Show every flag of the selected part of the collision")
    collision_material_shown: BoolProperty(name="Change Material", description="Show the list of collision materials")


class REDFORGE_OT_guide_start(bpy.types.Operator):
    bl_idname = "redforge.guide_start"
    bl_label = "Start"
    bl_options = {"INTERNAL"}
    flow: StringProperty()
    adopt: BoolProperty(description="Carry on with the object that's selected instead of making a new one")

    @classmethod
    def description(cls, context, properties):
        flow_ = FLOWS.get(properties.flow)
        if flow_ is None:
            return ""
        return "Carry on with the selected object, from the first step that's left" if properties.adopt else flow_.summary

    def execute(self, context):
        guide = context.scene.rf_guide
        flow_ = FLOWS[self.flow]
        guide.flow = self.flow
        flow_.begin(context, guide, flow_.adopt(context) if self.adopt else None)
        guide.name = ""
        guide.expanded = ""
        guide.step = first_open_step(context, guide, flow_) if self.adopt else 0
        return {"FINISHED"}


class REDFORGE_OT_guide_home(bpy.types.Operator):
    """Back to the list of what can be made. Nothing is lost: the object stays as it is"""
    bl_idname = "redforge.guide_home"
    bl_label = "Home"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        context.scene.rf_guide.flow = ""
        return {"FINISHED"}


class REDFORGE_OT_guide_step(bpy.types.Operator):
    """Open this step"""
    bl_idname = "redforge.guide_step"
    bl_label = "Go to Step"
    bl_options = {"INTERNAL"}
    index: IntProperty()

    def execute(self, context):
        guide = context.scene.rf_guide
        flow_ = FLOWS.get(guide.flow)
        if flow_ is not None:
            guide.step = max(0, min(self.index, len(flow_.steps) - 1))
        return {"FINISHED"}


class REDFORGE_PT_guide(bpy.types.Panel):
    bl_label = "Guide"
    bl_idname = "REDFORGE_PT_guide"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RedForge"
    bl_order = -3

    def draw_header(self, context):
        self.layout.label(text="", icon="INFO")

    def draw(self, context):
        guide = context.scene.rf_guide
        flow_ = FLOWS.get(guide.flow)
        if flow_ is None:
            self.draw_home(context)
        else:
            self.draw_flow(context, guide, flow_)
        self.layout.separator()
        self.layout.prop(get_addon_preferences(context), "show_expert_tools")

    def draw_home(self, context):
        layout = self.layout
        layout.label(text="What do you want to make?")
        col = layout.column(align=True)
        col.scale_y = 1.4
        for flow_ in FLOWS.values():
            col.operator(REDFORGE_OT_guide_start.bl_idname, text=flow_.label, icon=flow_.icon).flow = flow_.id
        for flow_ in FLOWS.values():
            obj = flow_.adopt(context)
            if obj is not None:
                box = layout.box()
                box.label(text=f"Selected: {obj.name}", icon=flow_.icon)
                op = box.operator(REDFORGE_OT_guide_start.bl_idname, text="Continue with It", icon="PLAY")
                op.flow = flow_.id
                op.adopt = True
        layout.separator()
        layout.operator("sollumz.import_assets", text="Open a Game File (.xml)", icon="IMPORT")

    def draw_flow(self, context, guide, flow_):
        layout = self.layout
        index = min(guide.step, len(flow_.steps) - 1)
        subject = flow_.subject(context, guide)

        row = layout.row(align=True)
        row.operator(REDFORGE_OT_guide_home.bl_idname, text="", icon="HOME")
        row.label(text=f"{flow_.label}: {subject}" if subject else flow_.label, icon=flow_.icon)

        states = [step.status(context, guide) for step in flow_.steps]
        col = layout.column(align=True)
        for i, (step, (state, note)) in enumerate(zip(flow_.steps, states)):
            split = col.split(factor=0.6, align=True)
            left = split.row(align=True)
            left.alignment = "LEFT"
            left.operator(REDFORGE_OT_guide_step.bl_idname, text=f"{i + 1}  {step.label}", icon=ICONS[state],
                          emboss=i == index, depress=i == index).index = i
            right = split.row()
            right.alignment = "RIGHT"
            right.active = state == PROBLEM
            right.label(text=note)

        step = flow_.steps[index]
        box = layout.box()
        box.label(text=step.label, icon=ICONS[states[index][0]])
        if step.intro:
            text(box, context, step.intro)
        step.draw(box, context, guide)

        row = layout.row(align=True)
        row.scale_y = 1.2
        back = row.row(align=True)
        back.enabled = index > 0
        back.operator(REDFORGE_OT_guide_step.bl_idname, text="Back", icon="TRIA_LEFT").index = index - 1
        if index < len(flow_.steps) - 1:
            skip = states[index][0] == OPTIONAL
            row.operator(REDFORGE_OT_guide_step.bl_idname, text="Skip" if skip else "Next", icon="TRIA_RIGHT",
                         depress=states[index][0] == DONE).index = index + 1


def register():
    bpy.types.Scene.rf_guide = PointerProperty(type=GuideState)
    bpy.types.WindowManager.rf_guide_flow = StringProperty(options={"SKIP_SAVE"})
    bpy.types.WindowManager.rf_guide_step = IntProperty(min=0, options={"SKIP_SAVE"})


def unregister():
    del bpy.types.Scene.rf_guide
    del bpy.types.WindowManager.rf_guide_flow
    del bpy.types.WindowManager.rf_guide_step
