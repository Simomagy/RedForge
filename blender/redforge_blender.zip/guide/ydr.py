"""The Guide's flow for a static model (.ydr): from plain meshes to the files RedForge takes."""
import os
import re

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty

from . import core
from .core import DONE, OPTIONAL, PROBLEM, TODO, Flow, Step, flow, select_only, target_of, text
from ..lods import SOLLUMZ_OT_HIDE_COLLISIONS, SOLLUMZ_OT_SHOW_COLLISIONS, set_all_lods
from ..sollumz_helper import find_sollumz_parent, textures_not_embedded
from ..sollumz_preferences import get_export_settings
from ..sollumz_properties import BOUND_TYPES, ArchetypeType, LODLevel, MaterialType, SollumType, SOLLUMZ_UI_NAMES
from ..tools.blenderhelper import duplicate_object
from ..tools.boundhelper import convert_objs_to_single_composite
from ..tools.meshhelper import (
    get_color_attr_name, get_mesh_used_colors_indices, get_mesh_used_texcoords_indices, get_uv_map_name,
    mesh_add_missing_color_attrs, mesh_add_missing_uv_maps, mesh_rename_color_attrs_by_order, mesh_rename_uv_maps_by_order,
)
from ..tools.texturehelper import write_texture
from ..tools.drawablehelper import center_drawable_to_models, convert_obj_to_drawable, convert_obj_to_model, convert_objs_to_single_drawable
from ..ybn.collision_materials import create_collision_material_from_index
from ..ybn.ui import SOLLUMZ_UL_COLLISION_MATERIALS_LIST
from ..ydr.operators.materials import (
    MaterialConverter, post_create_shader_add_default_images, post_create_shader_update_object,
    shader_preset_apply_to_material, shader_preset_from_material,
)
from ..ydr.shader_materials import create_shader, rdr_shadermats

EMBEDDED_FLAGS = 402685954  # (what Set all Textures Embedded gives a texture)


def game_name(name: str) -> str:
    """A name the game takes: lowercase, no spaces, without Blender's .001."""
    name = re.sub(r"\.\d+$", "", name.strip().lower())
    return re.sub(r"[^a-z0-9_]+", "_", name).strip("_")


def plain_meshes(context):
    """The selected meshes that aren't part of a game object yet."""
    return [obj for obj in context.selected_objects if obj.type == "MESH" and obj.sollum_type == SollumType.NONE]


def models_of(target):
    return [obj for obj in target.children if obj.type == "MESH" and obj.sollum_type == SollumType.DRAWABLE_MODEL]


def lod_meshes(model):
    """level -> mesh, for the levels the model has."""
    meshes = {level: model.sz_lods.get_lod(level).mesh for level in LODLevel}
    return {level: mesh for level, mesh in meshes.items() if mesh is not None}


def materials_of(target):
    """Every material of the model's meshes with a mesh object that uses it, and the mesh objects that have none."""
    materials, bare = {}, []
    for model in models_of(target):
        found = False
        for mesh in {model.data, *lod_meshes(model).values()}:
            for material in mesh.materials:
                if material is not None:
                    materials.setdefault(material, model)
                    found = True
        if not found:
            bare.append(model)
    return materials, bare


TEXTURES = {"diffusetex": "Colour", "bumptex": "Normal Map", "speculartex": "Specular", "speculartex2": "Specular 2",
            "tintpalettetex": "Tint Palette", "detailtexarrayn": "Detail"}  # a shader's textures, as the Guide calls them


def texture_nodes(material, known_only=False):
    """The material's texture slots. Known only: without the ones the game's shaders name by a hash, which nobody
    fills by hand (they're in the material's own panel)."""
    return [node for node in material.node_tree.nodes if isinstance(node, bpy.types.ShaderNodeTexImage)
            and getattr(node, "is_sollumz", True) and not (known_only and re.search(r"_0x[0-9A-Fa-f]{8}$", node.name))]


def empty_textures(target) -> int:
    """Texture slots with no picture: none at all, or the blank one a new material starts with."""
    return sum(1 for material in materials_of(target)[0] if material.sollum_type == MaterialType.SHADER
               for node in texture_nodes(material, known_only=True) if node.image is None or node.image.source == "GENERATED")


def meshes_missing_data(target) -> list:
    """The model's meshes with an empty material slot, or without a UV map or colour attribute their shaders read
    (under the name the export looks for)."""
    missing = []
    for model in models_of(target):
        for mesh in {model.data, *lod_meshes(model).values()}:
            if (any(material is None for material in mesh.materials)
                    or any(get_uv_map_name(i) not in mesh.uv_layers for i in get_mesh_used_texcoords_indices(mesh))
                    or any(get_color_attr_name(i) not in mesh.color_attributes for i in get_mesh_used_colors_indices(mesh))):
                missing.append(mesh)
    return missing


def fix_mesh_data(target) -> int:
    """Removes the empty material slots, names the UV maps and colour attributes the way the shaders read them
    (UVMap 0, Color 1...), and adds the ones that aren't there."""
    meshes = meshes_missing_data(target)
    for mesh in meshes:
        for index in reversed([i for i, material in enumerate(mesh.materials) if material is None]):
            mesh.materials.pop(index=index)  # (an empty slot: its faces go to a slot that has a material)
        mesh_rename_uv_maps_by_order(mesh)
        mesh_rename_color_attrs_by_order(mesh)
        mesh_add_missing_uv_maps(mesh)
        mesh_add_missing_color_attrs(mesh)
    return len(meshes)


def bounds_of(target):
    return [obj for obj in target.children_recursive if obj.sollum_type in BOUND_TYPES]


def ytd_name(context, target) -> str:
    """The texture dictionary the model's textures go in when they aren't in its file: the one its archetype names,
    or one named after the model."""
    _, archetype = archetype_of(context, target)
    return game_name((archetype.texture_dictionary if archetype is not None else "") or target.name)


def write_ytd(context, target, folder: str) -> str | None:
    """Writes <name>.ytd.xml in the folder, with the model's textures that aren't in its file as <name>/<texture>.dds
    (what RedForge makes a .ytd of). Returns the XML's path, None when every texture is in the model's file."""
    _, archetype = archetype_of(context, target)
    if archetype is not None and not archetype.texture_dictionary and textures_not_embedded(target):
        archetype.texture_dictionary = game_name(target.name)  # (or the game wouldn't look in the .ytd made here)
    images = {node.image for material in materials_of(target)[0] if material.sollum_type == MaterialType.SHADER
              for node in texture_nodes(material) if node.image is not None and not node.texture_properties.embedded}
    name = ytd_name(context, target)
    names = sorted({os.path.splitext(os.path.basename(image.filepath))[0] for image in images
                    if write_texture(image, os.path.join(folder, name))})
    if not names:
        return None
    items = "".join(f"  <Item>\n   <Name>{texture}</Name>\n  </Item>\n" for texture in names)
    path = os.path.join(folder, f"{name}.ytd.xml")
    with open(path, "w", encoding="utf8") as file:
        file.write(f'<?xml version="1.0" encoding="UTF-8"?>\n<RDR2TextureDictionary version="1">\n <Textures>\n{items} </Textures>\n</RDR2TextureDictionary>\n')
    return path


def collision_meshes(target):
    """The meshes of the model's collision: the ones with its materials (the triangles under a BVH aren't a bound
    themselves, so they're found by what they're under)."""
    return [obj for bound in bounds_of(target) for obj in [bound, *bound.children] if obj.type == "MESH"]


def archetype_of(context, target):
    """The ytyp and archetype that have the model as their asset."""
    for ytyp in context.scene.ytyps:
        for archetype in ytyp.archetypes:
            if archetype.asset == target:
                return ytyp, archetype
    return None, None


def mesh_problems(obj) -> list[tuple[str, bool]]:
    """What's wrong with a mesh before it's made a model: (what, whether Apply fixes it)."""
    problems = []
    if not obj.data.polygons:
        problems.append(("has no faces", False))
    if any(abs(s - 1.0) > 1e-4 for s in obj.scale) or any(abs(r) > 1e-4 for r in obj.rotation_euler):
        problems.append(("rotation or scale not applied", True))
    if not obj.data.uv_layers:
        problems.append(("has no UV map: textures can't be placed on it", False))
    return problems


def needs_model(layout, context, guide) -> bool:
    if target_of(context, guide) is not None:
        return False
    text(layout, context, "There's no model yet: make it in step 2.", icon="INFO")
    return True


# ---- steps


class Meshes(Step):
    label = "Meshes"
    intro = "A model is made of one or more mesh objects. Select the ones that make up yours."

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is not None:
            return DONE, f"{len(models_of(target))} mesh(es)"
        meshes = plain_meshes(context)
        if not meshes:
            return TODO, "select"
        wrong = sum(1 for obj in meshes if mesh_problems(obj))
        return (PROBLEM, f"{wrong} to fix") if wrong else (DONE, f"{len(meshes)} selected")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        if target is not None:
            col = layout.column(align=True)
            for model in models_of(target):
                row = col.row()
                row.label(text=model.name, icon="MESH_DATA")
                sub = row.row()
                sub.alignment = "RIGHT"
                sub.label(text=f"{len(model.data.polygons)} faces")
            more = plain_meshes(context)
            if more:
                layout.operator(REDFORGE_OT_guide_add_meshes.bl_idname, text=f"Add {len(more)} Selected Mesh(es) to the Model", icon="ADD")
            return
        meshes = plain_meshes(context)
        if not meshes:
            layout.label(text="No mesh selected", icon="INFO")
            return
        fixable = False
        col = layout.column(align=True)
        for obj in meshes:
            problems = mesh_problems(obj)
            col.label(text=obj.name, icon="ERROR" if problems else "CHECKMARK")
            for what, by_apply in problems:
                text(col, context, what, icon="BLANK1")
                fixable = fixable or by_apply
        if fixable:
            layout.operator(REDFORGE_OT_guide_apply_transforms.bl_idname, icon="CHECKMARK")


class Model(Step):
    label = "Model"
    intro = "The meshes become one game model (a Drawable). Its name is the file's name, and what maps call it."

    def status(self, context, guide):
        target = target_of(context, guide)
        return (DONE, target.name) if target is not None else (TODO, "")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        if target is not None:
            layout.prop(target, "name", text="Name")
            layout.operator(REDFORGE_OT_guide_new.bl_idname, icon="ADD")
            return
        meshes = plain_meshes(context)
        if not meshes:
            text(layout, context, "Select the meshes first (step 1).", icon="INFO")
            return
        layout.prop(guide, "name")
        name = game_name(guide.name or (context.active_object if context.active_object in meshes else meshes[0]).name)
        layout.label(text=f"It will be: {name}.ydr", icon="FILE")
        if len(meshes) > 1:
            layout.prop(context.scene, "center_drawable_to_selection", text="Origin at the Meshes' Center")
        row = layout.row()
        row.scale_y = 1.4
        row.operator(REDFORGE_OT_guide_create_model.bl_idname, icon="OUTLINER_OB_MESH")


class Materials(Step):
    label = "Materials"
    intro = "The game draws with its own shaders: every material has to be one. Click a material for its textures, its shader's name to pick another."

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        materials, bare = materials_of(target)
        wrong = sum(1 for m in materials if m.sollum_type != MaterialType.SHADER) + len(bare)
        if wrong:
            return PROBLEM, f"{wrong} to fix"
        if meshes_missing_data(target):
            return PROBLEM, "mesh data"
        empty = empty_textures(target)
        return DONE, f"{empty} empty" if empty else f"{len(materials)} material(s)"

    def draw(self, layout, context, guide):
        if needs_model(layout, context, guide):
            return
        target = target_of(context, guide)
        materials, bare = materials_of(target)
        col = layout.column(align=True)
        for material in materials:
            is_shader = material.sollum_type == MaterialType.SHADER
            row = col.row(align=True)
            left = row.row(align=True)
            left.alignment = "LEFT"
            left.operator(REDFORGE_OT_guide_expand.bl_idname, text=material.name, emboss=False,
                          icon="CHECKMARK" if is_shader else "ERROR").material = material.name
            right = row.row(align=True)
            right.alignment = "RIGHT"
            if is_shader:
                right.operator(REDFORGE_OT_guide_shader.bl_idname, text=material.shader_properties.filename,
                               icon="DOWNARROW_HLT").material = material.name
            else:
                right.operator(REDFORGE_OT_guide_convert_materials.bl_idname, text="Convert").material = material.name
                right.operator(REDFORGE_OT_guide_shader.bl_idname, text="", icon="DOWNARROW_HLT").material = material.name
            if is_shader and guide.expanded == material.name:
                box = col.box()
                for node in texture_nodes(material, known_only=True):
                    box.label(text=TEXTURES.get(node.name, node.name))
                    box.template_ID(node, "image", open="image.open")
        for model in bare:
            row = col.row(align=True)
            row.label(text=f"{model.name}: no material", icon="ERROR")
            row.operator(REDFORGE_OT_guide_shader.bl_idname, text="Add", icon="DOWNARROW_HLT").object = model.name
        if any(m.sollum_type != MaterialType.SHADER for m in materials):
            layout.operator(REDFORGE_OT_guide_convert_materials.bl_idname, text="Convert All", icon="FILE_REFRESH").material = ""

        missing = meshes_missing_data(target)
        if missing:
            text(layout, context, f"{len(missing)} mesh(es) have an empty material slot, or lack a UV map or colour attribute their shader reads.", icon="ERROR")
            layout.operator(REDFORGE_OT_guide_fix_mesh_data.bl_idname, icon="CHECKMARK")

        if any(m.sollum_type == MaterialType.SHADER for m in materials):
            layout.separator()
            layout.label(text="Where the textures go", icon="TEXTURE")
            outside = textures_not_embedded(target)
            row = layout.row(align=True)
            row.operator(REDFORGE_OT_guide_embed_textures.bl_idname, text="In the Model's File", depress=not outside).embed = True
            row.operator(REDFORGE_OT_guide_embed_textures.bl_idname, text="In a .ytd", depress=bool(outside)).embed = False
            text(layout, context, f"In {ytd_name(context, target)}.ytd, made when the model is exported or sent. The archetype (step 6) names it."
                 if outside else "In the model's file: nothing else is needed.")
            empty = empty_textures(target)
            if empty:
                text(layout, context, f"{empty} texture slot(s) have no picture yet.", icon="INFO")


class LODs(Step):
    label = "Levels of Detail"
    intro = "Lighter versions of the model, drawn when it's far away. A small prop does without."

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        levels = set().union(*(lod_meshes(model) for model in models_of(target))) if models_of(target) else set()
        return (DONE, f"{len(levels)} levels") if len(levels) > 1 else (OPTIONAL, "optional")

    def draw(self, layout, context, guide):
        if needs_model(layout, context, guide):
            return
        target = target_of(context, guide)
        models = models_of(target)
        faces = {}
        for model in models:
            for level, mesh in lod_meshes(model).items():
                faces[level] = faces.get(level, 0) + len(mesh.polygons)
        shown = models[0].sz_lods.active_lod_level if models else None
        col = layout.column(align=True)
        for level in LODLevel:
            if level not in faces and level == LODLevel.VERYHIGH:
                continue
            row = col.row(align=True)
            sub = row.row(align=True)
            sub.enabled = level in faces
            sub.operator(REDFORGE_OT_guide_show_lod.bl_idname, text=SOLLUMZ_UI_NAMES[level], depress=shown == level).level = level.value
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.label(text=f"{faces[level]} faces" if level in faces else "none")

        layout.separator()
        layout.label(text="Make them from High", icon="MOD_DECIM")
        layout.prop(guide, "lod_levels")
        layout.prop(context.scene, "sollumz_auto_lod_decimate_step", text="Faces Removed at Each Level", slider=True)
        layout.operator(REDFORGE_OT_guide_generate_lods.bl_idname, icon="MOD_DECIM")

        if len(faces) > 1:
            layout.separator()
            layout.label(text="Drawn up to (metres)", icon="DRIVER_DISTANCE")
            props = target.drawable_properties
            col = layout.column(align=True)
            for level, name in ((LODLevel.HIGH, "lod_dist_high"), (LODLevel.MEDIUM, "lod_dist_med"),
                                (LODLevel.LOW, "lod_dist_low"), (LODLevel.VERYLOW, "lod_dist_vlow")):
                if level in faces:
                    col.prop(props, name, text=SOLLUMZ_UI_NAMES[level])


class Collision(Step):
    label = "Collision"
    intro = "What the player and objects bump into and stand on. Without it everything goes through the model."

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        return (DONE, "in the model") if bounds_of(target) else (OPTIONAL, "optional")

    def draw_materials(self, layout, context):
        wm = context.window_manager
        layout.template_list(SOLLUMZ_UL_COLLISION_MATERIALS_LIST.bl_idname, "rf_guide", wm, "sz_collision_materials",
                             wm, "sz_collision_material_index", rows=4)

    def draw(self, layout, context, guide):
        if needs_model(layout, context, guide):
            return
        target = target_of(context, guide)
        bounds = bounds_of(target)
        if not bounds:
            layout.label(text="What it's made of (sounds, bullet marks)")
            self.draw_materials(layout, context)
            col = layout.column(align=True)
            col.scale_y = 1.2
            col.operator(REDFORGE_OT_guide_collision.bl_idname, text="From the Model's Shape", icon="MESH_DATA").source = "MODEL"
            row = col.row(align=True)
            row.enabled = bool(plain_meshes(context))
            row.operator(REDFORGE_OT_guide_collision.bl_idname, text="From the Selected Mesh(es)", icon="RESTRICT_SELECT_OFF").source = "SELECTED"
            text(layout, context, "A simpler mesh made for it is lighter for the game than the model's own shape.")
            return
        col = layout.column(align=True)
        for obj in dict.fromkeys(collision_meshes(target)):
            row = col.row()
            row.label(text=obj.name, icon="MESH_DATA")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.label(text=", ".join(m.name for m in obj.data.materials if m is not None) or "no material")
        layout.prop(guide, "collision_material_shown", icon="MATERIAL", toggle=True)
        if guide.collision_material_shown:
            self.draw_materials(layout, context)
            layout.operator(REDFORGE_OT_guide_collision.bl_idname, text="Use This Material").source = "MATERIAL"
        row = layout.row(align=True)
        if context.scene.sollumz_show_collisions:
            row.operator(SOLLUMZ_OT_HIDE_COLLISIONS.bl_idname, icon="HIDE_OFF")
        else:
            row.operator(SOLLUMZ_OT_SHOW_COLLISIONS.bl_idname, icon="HIDE_ON")
        row.operator(REDFORGE_OT_guide_collision.bl_idname, text="Remove", icon="TRASH").source = "REMOVE"


class Archetype(Step):
    label = "Archetype"
    intro = "The model's entry in a .ytyp: what it is to the game. Without one, maps can't place the model."

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        ytyp, archetype = archetype_of(context, target)
        if archetype is None:
            return TODO, "to place it"
        return (PROBLEM, "other name") if game_name(archetype.name) != game_name(target.name) else (DONE, f"{ytyp.name}.ytyp")

    def draw(self, layout, context, guide):
        if needs_model(layout, context, guide):
            return
        target = target_of(context, guide)
        ytyp, archetype = archetype_of(context, target)
        if archetype is None:
            layout.prop(context.scene, "create_archetype_kind", text="It's a")
            if len(context.scene.ytyps):
                layout.prop_search(guide, "ytyp", context.scene, "ytyps", text="In")
            text(layout, context, f"Goes in {guide.ytyp}.ytyp." if guide.ytyp in context.scene.ytyps
                 else f"Goes in a new {game_name(target.name)}.ytyp.")
            row = layout.row()
            row.scale_y = 1.4
            row.operator(REDFORGE_OT_guide_create_archetype.bl_idname, icon="ADD")
            return
        layout.label(text=f"{archetype.name}, in {ytyp.name}.ytyp", icon="CHECKMARK")
        if game_name(archetype.name) != game_name(target.name):
            text(layout, context, f"The model is now named {target.name}: the game wouldn't find it.", icon="ERROR")
            layout.operator(REDFORGE_OT_guide_rename_archetype.bl_idname, icon="FILE_REFRESH")
        col = layout.column()
        col.use_property_split = True
        col.use_property_decorate = False
        col.prop(archetype, "lod_dist", text="Drawn up to")
        col.prop(archetype, "texture_dictionary", text="Textures")
        col.prop(archetype, "physics_dictionary", text="Collision")
        outside = textures_not_embedded(target)
        if outside and not archetype.texture_dictionary:
            text(layout, context, f"{len(outside)} texture(s) aren't in the model's file: Textures must name the .ytd that has them.", icon="ERROR")


class Export(Step):
    label = "Check & Export"
    intro = "What's left to fix, then the files: to a folder, or straight into RedForge's project."

    def issues(self, context, guide) -> list[tuple[int, str]]:
        """(the step to fix it in, what's wrong)."""
        target = target_of(context, guide)
        issues = []
        for index, step in enumerate(YdrFlow.steps[:-1]):
            state, note = step.status(context, guide)
            if state == PROBLEM or (state == TODO and (target is None or not isinstance(step, Archetype))):
                issues.append((index, f"{step.label}: {note}" if note else f"{step.label}: not done"))
        if target is None:
            return issues
        if target.name != game_name(target.name):
            issues.append((1, f"The name {target.name} will be written as {game_name(target.name)}"))
        _, archetype = archetype_of(context, target)
        if archetype is not None and textures_not_embedded(target) and not archetype.texture_dictionary:
            issues.append((5, "The archetype doesn't name the .ytd with the textures"))
        return issues

    def status(self, context, guide):
        issues = self.issues(context, guide)
        return (PROBLEM, f"{len(issues)} to fix") if issues else (TODO, "ready")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        issues = self.issues(context, guide)
        for index, what in issues:
            row = layout.row()
            text(row, context, what, icon="ERROR")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.operator(core.REDFORGE_OT_guide_step.bl_idname, text="Fix").index = index
        if target is None:
            return
        if not issues:
            layout.label(text="Nothing to fix", icon="CHECKMARK")
        if archetype_of(context, target)[1] is None:
            text(layout, context, "No archetype: the model's file alone is exported.", icon="INFO")

        from ..redforge import bridge, link
        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.enabled = not any(index < 3 for index, _ in issues)
        row = col.row(align=True)
        row.enabled = link.connected()
        row.operator(REDFORGE_OT_guide_send.bl_idname, icon="EXPORT",
                     text="Send Changes to RedForge" if bridge.FILE_KEY in target else "Send to RedForge")
        col.operator(REDFORGE_OT_guide_export.bl_idname, icon="FILE_FOLDER")
        if not link.connected():
            layout.label(text="RedForge isn't running", icon="UNLINKED")
        layout.prop(context.scene, "sollumz_export_path", text="Folder")


@flow
class YdrFlow(Flow):
    id = "ydr"
    label = "Model (YDR)"
    icon = "MESH_CUBE"
    summary = "A static model: a building, a rock, a piece of furniture. From your meshes to the .ydr and its archetype"
    steps = (Meshes(), Model(), Materials(), LODs(), Collision(), Archetype(), Export())

    def adopt(self, context):
        obj = context.active_object
        if obj is None or not obj.select_get():
            return None
        root = find_sollumz_parent(obj)
        return root if (root is not None and root.sollum_type == SollumType.DRAWABLE) else None


# ---- operators


class GuideOperator:
    """An operator on the Guide's model."""
    bl_options = {"UNDO", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        guide = context.scene.rf_guide
        try:
            message = self.run(context, guide, target_of(context, guide))
        except Exception as ex:
            self.report({"ERROR"}, str(ex))
            return {"CANCELLED"}
        if message:
            self.report({"INFO"}, message)
        return {"FINISHED"}


class REDFORGE_OT_guide_apply_transforms(GuideOperator, bpy.types.Operator):
    """Apply the rotation and scale of the selected meshes, so the game gets them the size and way they look here"""
    bl_idname = "redforge.guide_apply_transforms"
    bl_label = "Apply Rotation & Scale"

    def run(self, context, guide, target):
        meshes = plain_meshes(context)
        select_only(context, meshes)
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


class REDFORGE_OT_guide_create_model(GuideOperator, bpy.types.Operator):
    """Make a game model (Drawable) of the selected meshes"""
    bl_idname = "redforge.guide_create_model"
    bl_label = "Create the Model"

    def run(self, context, guide, target):
        meshes = plain_meshes(context)
        if not meshes:
            raise RuntimeError("No mesh selected")
        first = context.active_object if context.active_object in meshes else meshes[0]
        name = game_name(guide.name or first.name)
        if not name:
            raise RuntimeError("The model needs a name")
        game = context.scene.sollum_game_type
        with context.temp_override(collection=first.users_collection[0]):  # (next to the meshes, not in the active collection)
            if len(meshes) == 1:
                drawable = convert_obj_to_drawable(first, game)
            else:
                drawable = convert_objs_to_single_drawable(meshes, game)
                if context.scene.center_drawable_to_selection:
                    center_drawable_to_models(drawable)
        models = models_of(drawable)
        for index, model in enumerate(models):  # (the meshes first: one of them may have the model's name)
            model.name = f"{name}.model" if len(models) == 1 else f"{name}.model{index + 1}"
        drawable.name = name
        guide.target = drawable
        guide.name = ""
        guide.step = 2
        select_only(context, [drawable])
        return f"{drawable.name} is a model now"


class REDFORGE_OT_guide_add_meshes(GuideOperator, bpy.types.Operator):
    """Make the selected meshes part of the model"""
    bl_idname = "redforge.guide_add_meshes"
    bl_label = "Add Meshes to the Model"

    def run(self, context, guide, target):
        meshes = plain_meshes(context)
        for obj in meshes:
            world = obj.matrix_world.copy()
            convert_obj_to_model(obj, context.scene.sollum_game_type)
            obj.parent = target
            obj.matrix_world = world
            obj.name = f"{target.name}.model{len(models_of(target))}"
        return f"{len(meshes)} mesh(es) added to {target.name}"


class REDFORGE_OT_guide_new(GuideOperator, bpy.types.Operator):
    """Leave this model as it is and start another one from the first step"""
    bl_idname = "redforge.guide_new"
    bl_label = "Make Another Model"

    def run(self, context, guide, target):
        guide.target = None
        guide.name = ""
        guide.step = 0
        select_only(context, [])


class REDFORGE_OT_guide_expand(bpy.types.Operator):
    """Show or hide the material's textures"""
    bl_idname = "redforge.guide_expand"
    bl_label = "Show Textures"
    bl_options = {"INTERNAL"}
    material: StringProperty()

    def execute(self, context):
        guide = context.scene.rf_guide
        guide.expanded = "" if guide.expanded == self.material else self.material
        return {"FINISHED"}


class REDFORGE_OT_guide_convert_materials(GuideOperator, bpy.types.Operator):
    """Make a game shader of the material, picked from what it has: its picture, normal map and specular map are kept"""
    bl_idname = "redforge.guide_convert_materials"
    bl_label = "Convert Materials"
    material: StringProperty(description="The material to convert. Empty: every one of the model's that isn't a shader")

    def run(self, context, guide, target):
        done, failed = 0, []
        for material, model in materials_of(target)[0].items():
            if material.sollum_type == MaterialType.SHADER or (self.material and material.name != self.material):
                continue
            try:
                converted = MaterialConverter(model, material).auto_convert()
            except Exception as ex:
                converted = None
                print(f"RedForge Guide: {material.name}: {ex}")
            if converted is None:
                failed.append(material.name)
            else:
                done += 1
        fix_mesh_data(target)
        if failed:
            raise RuntimeError(f"Couldn't convert {', '.join(failed)}: its nodes aren't ones the converter reads (see the console)")
        return f"{done} material(s) converted"


class REDFORGE_OT_guide_shader(GuideOperator, bpy.types.Operator):
    """Pick the shader from the game's list (type to search): for this material, keeping the textures and values the
    two shaders share, or for a new material on a mesh that has none"""
    bl_idname = "redforge.guide_shader"
    bl_label = "Choose the Shader"
    bl_property = "shader"
    material: StringProperty(description="The material that gets the shader")
    object: StringProperty(description="The mesh that gets a new material with the shader, when no material is named")
    shader: EnumProperty(name="Shader", items=tuple((s.value, s.value, s.ui_name.title()) for s in rdr_shadermats))

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"FINISHED"}

    def run(self, context, guide, target):
        game = context.scene.sollum_game_type
        if not self.material:
            obj = context.scene.objects[self.object]
            material = create_shader(self.shader, game)
            empty = next((i for i, slot in enumerate(obj.data.materials) if slot is None), None)
            if empty is None:
                obj.data.materials.append(material)
            else:
                obj.data.materials[empty] = material  # (the slot its faces already use)
            post_create_shader_add_default_images(material)
        else:
            material = bpy.data.materials[self.material]
            users = [model for model in models_of(target)
                     if any(material.name in mesh.materials for mesh in {model.data, *lod_meshes(model).values()})]
            if material.sollum_type == MaterialType.SHADER:  # (in place, the way Change Shader does it)
                preset = shader_preset_from_material(material)
                create_shader(self.shader, game, in_place_material=material)
                shader_preset_apply_to_material(material, preset, apply_textures=True)
                post_create_shader_add_default_images(material)
            else:
                material = MaterialConverter(users[0], material).convert(self.shader, game)
        for model in models_of(target):  # (the UV maps and colours the new shader reads)
            if material.name in model.data.materials:
                post_create_shader_update_object(model, material)
        fix_mesh_data(target)
        guide.expanded = material.name
        return f"{material.name} uses {self.shader}"


class REDFORGE_OT_guide_fix_mesh_data(GuideOperator, bpy.types.Operator):
    """Remove the meshes' empty material slots, name their UV maps and colour attributes the way the shaders read them, and add the ones that aren't there"""
    bl_idname = "redforge.guide_fix_mesh_data"
    bl_label = "Fix the Meshes"

    def run(self, context, guide, target):
        return f"{fix_mesh_data(target)} mesh(es) fixed"


class REDFORGE_OT_guide_embed_textures(GuideOperator, bpy.types.Operator):
    """Where the game finds the model's textures: inside the model's own file, or in a texture dictionary (.ytd) made apart"""
    bl_idname = "redforge.guide_embed_textures"
    bl_label = "Textures in the Model's File"
    embed: BoolProperty()

    def run(self, context, guide, target):
        for material in materials_of(target)[0]:
            if material.sollum_type != MaterialType.SHADER:
                continue
            for node in texture_nodes(material):
                node.texture_properties.embedded = self.embed
                node.texture_properties.extra_flags = EMBEDDED_FLAGS if self.embed else 0


class REDFORGE_OT_guide_show_lod(GuideOperator, bpy.types.Operator):
    """Show this level of detail of the model"""
    bl_idname = "redforge.guide_show_lod"
    bl_label = "Show Level"
    bl_options = {"INTERNAL"}
    level: StringProperty()

    def run(self, context, guide, target):
        set_all_lods(target, LODLevel(self.level))


class REDFORGE_OT_guide_generate_lods(GuideOperator, bpy.types.Operator):
    """Make the ticked levels from the High one, each with fewer faces than the one before. A level that exists is made again"""
    bl_idname = "redforge.guide_generate_lods"
    bl_label = "Make the Levels"

    def run(self, context, guide, target):
        if not guide.lod_levels:
            raise RuntimeError("No level is ticked")
        scene = context.scene
        before = (scene.sollumz_auto_lod_ref_mesh, set(scene.sollumz_auto_lod_levels))
        models = models_of(target)
        try:
            scene.sollumz_auto_lod_levels = set(guide.lod_levels)
            for model in models:
                high = lod_meshes(model).get(LODLevel.HIGH)
                if high is None:
                    raise RuntimeError(f"{model.name} has no High level to make the others from")
                model.sz_lods.active_lod_level = LODLevel.HIGH
                select_only(context, [model])
                scene.sollumz_auto_lod_ref_mesh = high
                if "FINISHED" not in bpy.ops.sollumz.auto_lod():
                    raise RuntimeError(f"The levels of {model.name} weren't made")
        finally:
            scene.sollumz_auto_lod_ref_mesh, scene.sollumz_auto_lod_levels = before
            select_only(context, [target])
        return f"{len(guide.lod_levels)} level(s) made for {len(models)} mesh(es)"


class REDFORGE_OT_guide_collision(GuideOperator, bpy.types.Operator):
    """The model's collision: made from its own shape or from the selected meshes, given the material picked in the list, or removed"""
    bl_idname = "redforge.guide_collision"
    bl_label = "Collision"
    source: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {
            "MODEL": "Make the collision a copy of the model's meshes",
            "SELECTED": "Make the collision of the selected meshes, ones made for it: simpler than the model",
            "MATERIAL": "Give the collision the material picked in the list",
            "REMOVE": "Delete the model's collision",
        }.get(properties.source, "")

    def run(self, context, guide, target):
        game = context.scene.sollum_game_type
        material_index = context.window_manager.sz_collision_material_index
        bounds = bounds_of(target)
        if self.source == "REMOVE":
            for obj in {*bounds, *collision_meshes(target)}:  # (the triangles too: they'd be left loose in the scene)
                bpy.data.objects.remove(obj, do_unlink=True)
            return "Collision removed"
        if self.source == "MATERIAL":
            meshes = list(dict.fromkeys(collision_meshes(target)))
            if not meshes:
                raise RuntimeError("The collision has no mesh to give the material to")
        else:
            if bounds:
                raise RuntimeError("The model has a collision already")
            if self.source == "SELECTED":
                meshes = plain_meshes(context)
                worlds = [obj.matrix_world.copy() for obj in meshes]
            else:
                set_all_lods(target, LODLevel.HIGH)
                meshes = [duplicate_object(model) for model in models_of(target)]
                worlds = [obj.matrix_world.copy() for obj in meshes]
                for obj in meshes:  # (a copy of its own mesh: the model's keeps its materials)
                    obj.data = obj.data.copy()
            if not meshes:
                raise RuntimeError("No mesh to make the collision of")
            with context.temp_override(collection=target.users_collection[0]):
                composite = convert_objs_to_single_composite(meshes, SollumType.BOUND_GEOMETRYBVH, game,
                                                             context.window_manager.sz_flag_preset_index)
            composite.name = f"{target.name}.col"
            composite.parent = target
            context.view_layer.update()
            for obj, world in zip(meshes, worlds):  # (where they were, whatever they were parented to)
                obj.matrix_world = world
        for obj in meshes:
            obj.data.materials.clear()
            obj.data.materials.append(create_collision_material_from_index(material_index, game))
        guide.collision_material_shown = False
        select_only(context, [target])
        return "Collision material set" if self.source == "MATERIAL" else f"Collision made of {len(meshes)} mesh(es)"


class REDFORGE_OT_guide_create_archetype(GuideOperator, bpy.types.Operator):
    """Make the model's archetype, in the ytyp chosen or a new one named after the model"""
    bl_idname = "redforge.guide_create_archetype"
    bl_label = "Create the Archetype"

    def run(self, context, guide, target):
        scene = context.scene
        index = scene.ytyps.find(guide.ytyp) if guide.ytyp else -1
        if index < 0:
            bpy.ops.sollumz.createytyp()
            index = scene.ytyp_index
            scene.ytyps[index].name = game_name(target.name)
        scene.ytyp_index = index
        scene.create_archetype_type = ArchetypeType.BASE
        select_only(context, [target])
        bpy.ops.sollumz.createarchetypefromselected()
        ytyp, archetype = archetype_of(context, target)
        if archetype is None:
            raise RuntimeError("The archetype wasn't made")
        if textures_not_embedded(target) and not archetype.texture_dictionary:
            archetype.texture_dictionary = game_name(target.name)  # (the .ytd the Guide makes of them)
        guide.ytyp = ""
        return f"{archetype.name} is in {ytyp.name}.ytyp"


class REDFORGE_OT_guide_rename_archetype(GuideOperator, bpy.types.Operator):
    """Give the archetype the model's name"""
    bl_idname = "redforge.guide_rename_archetype"
    bl_label = "Rename the Archetype"

    def run(self, context, guide, target):
        _, archetype = archetype_of(context, target)
        old, new = archetype.name, game_name(target.name)
        archetype.name = new
        archetype.asset_name = target.name
        for name in ("texture_dictionary", "physics_dictionary"):  # (the ones named after the model follow it)
            if getattr(archetype, name) == old:
                setattr(archetype, name, new)


class REDFORGE_OT_guide_export(GuideOperator, bpy.types.Operator):
    """Write the model's .ydr.xml in the folder, and the .ytyp.rsc.xml that has its archetype (the name RedForge reads a ytyp from)"""
    bl_idname = "redforge.guide_export"
    bl_label = "Export to the Folder"
    bl_options = {"INTERNAL"}

    def run(self, context, guide, target):
        scene = context.scene
        folder = bpy.path.abspath(scene.sollumz_export_path)
        if not scene.sollumz_export_path or not os.path.isdir(folder):
            raise RuntimeError("Choose the folder to export to")
        settings = get_export_settings(context)
        wanted = {"limit_to_selected": True, "export_with_ytyp": False}  # (its own ytyp is written below)
        before = {name: getattr(settings, name) for name in wanted}
        changed = [name for name in wanted if before[name] != wanted[name]]  # (setting one saves the preferences)
        select_only(context, [target])
        try:
            for name in changed:
                setattr(settings, name, wanted[name])
            if "FINISHED" not in bpy.ops.sollumz.export_assets(directory=folder, direct_export=True):
                raise RuntimeError("The model wasn't exported: see the Info log")
        finally:
            for name in changed:
                setattr(settings, name, before[name])
        written = [f"{game_name(target.name)}.ydr.xml"]
        ytd = write_ytd(context, target, folder)  # (before the ytyp: its archetype names the .ytd)
        if ytd is not None:
            written.append(os.path.basename(ytd))
        ytyp, _ = archetype_of(context, target)
        if ytyp is not None:
            from ..ytyp.ytypexport import selected_ytyp_to_xml
            index = scene.ytyp_index
            try:
                scene.ytyp_index = scene.ytyps.find(ytyp.name)
                ytyp_xml = selected_ytyp_to_xml(settings.apply_transforms)
            finally:
                scene.ytyp_index = index
            ytyp_xml.write_xml(os.path.join(folder, f"{ytyp_xml.name}.ytyp.rsc.xml"))
            written.append(f"{ytyp_xml.name}.ytyp.rsc.xml")

        return f"Exported {' and '.join(written)}"


class REDFORGE_OT_guide_send(GuideOperator, bpy.types.Operator):
    """Put the model in RedForge's project, with the ytyp that has its archetype"""
    bl_idname = "redforge.guide_send"
    bl_label = "Send to RedForge"
    bl_options = {"INTERNAL"}

    def run(self, context, guide, target):
        import shutil
        import tempfile
        from ..redforge import bridge, link
        select_only(context, [target])
        if bridge.FILE_KEY in target:
            bridge._changed.add(target[bridge.FILE_KEY])  # (asked for: sent even if nothing changed since the last time)
        # The textures that aren't in the model's file: RedForge makes the .ytd of them. (Before the model: its
        # archetype, sent with it, names the .ytd.)
        name = ytd_name(context, target)
        staging = os.path.join(tempfile.gettempdir(), "RedForge", "Blender", "send", f"{name}.ytd")
        shutil.rmtree(staging, ignore_errors=True)
        ytd = write_ytd(context, target, staging)
        if ytd is not None:
            link.request(bridge.prefs(context).redforge_port, "import", xml=ytd, file=f"{name}.ytd")
        message = bridge.send_new(context, [target])
        if ytd is not None:
            message += f", {name}.ytd"
        return message
