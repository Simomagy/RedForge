"""The Guide's flow for a collision of its own (.ybn): what's walked on and bumped into, apart from any model. A piece
of the map's ground, an invisible wall, the collision an interior is made on."""
import os
import shutil
import tempfile

import bpy
from bpy.props import StringProperty

from . import core
from .core import DONE, OPTIONAL, PROBLEM, TODO, Flow, Step, flow, select_only, target_of, text
from .ydr import GuideOperator, game_name, plain_meshes
from ..lods import SOLLUMZ_OT_HIDE_COLLISIONS, SOLLUMZ_OT_SHOW_COLLISIONS
from ..sollumz_preferences import get_export_settings
from ..sollumz_properties import BOUND_TYPES, MaterialType, SollumType
from ..tools.boundhelper import convert_obj_to_bvh, convert_objs_to_single_composite, create_bound_shape
from ..ybn.collision_materials import create_collision_material_from_index
from ..ybn.ui import SOLLUMZ_UL_COLLISION_MATERIALS_LIST

SHAPES = (  # the simple shapes: lighter for the game than a mesh
    (SollumType.BOUND_BOX, "Box", "MESH_CUBE"), (SollumType.BOUND_SPHERE, "Sphere", "MESH_UVSPHERE"),
    (SollumType.BOUND_CAPSULE, "Capsule", "MESH_CAPSULE"), (SollumType.BOUND_CYLINDER, "Cylinder", "MESH_CYLINDER"),
)
# A part of a collision has two sets of flags: what it is (its type), and what is checked against it (what it
# includes). The collisions of the game's own interiors (46 files, 179 parts looked at) only ever have seven
# combinations of them: these are the kinds the Guide offers, each with how many of the 179 have it.
_EVERYTHING = ("cf_ai_test", "cf_camera_test", "cf_explosion_type", "cf_forklift_forks_type", "cf_glass_type",
               "cf_horse_ragdoll_type", "cf_horse_type", "cf_object_type", "cf_ped_type", "cf_plant_type",
               "cf_projectile_type", "cf_ragdoll_type", "cf_script_test", "cf_vehicle_bvh_type", "cf_vehicle_non_bvh_type",
               "cf_wheel_test")
_MOVERS = ("cf_cover_type", "cf_map_type_horse", "cf_map_type_mover", "cf_map_type_vehicle")
KINDS = {  # id: (name, what it does, type flags, include flags, how many of the game's 179)
    "solid": ("Solid for Everything",
              "Stops people, horses, vehicles, objects and bullets, and cover can be taken behind it. One mesh that "
              "does it all: right for most collisions.",
              (*_MOVERS, "cf_map_type_weapon"), (*_EVERYTHING, "cf_weapon_test"), 54),
    "mover": ("Movement Only",
              "Stops people, horses, vehicles and objects, but bullets go through. The game pairs it with a Bullets "
              "Only part: a simple mesh to walk on and bump into, a detailed one to shoot at.",
              _MOVERS, _EVERYTHING, 32),
    "weapon": ("Bullets Only",
               "Stops bullets, projectiles and the camera; everything else goes through. The detailed mesh that goes "
               "with a Movement Only one.",
               ("cf_map_type_weapon",), ("cf_camera_test", "cf_projectile_type", "cf_weapon_test"), 54),
    "cover": ("Cover Only", "Not solid: where the game's characters can take cover.",
              ("cf_cover_type",), ("cf_ai_test",), 16),
    "camera": ("Camera Only", "Not solid: only keeps the camera from going through.",
               ("cf_map_type_camera",), ("cf_camera_test",), 14),
    "stairs": ("Stair Slope",
               "The invisible slope laid over a staircase, that feet and hooves walk on instead of each step.",
               ("cf_stair_slope_type",),
               ("cf_ai_test", "cf_camera_test", "cf_horse_type", "cf_ped_type", "cf_script_test", "cf_weapon_test", "cf_wheel_test"), 8),
    "horse_avoidance": ("Movement Only, Horses Avoid It",
                        "As Movement Only, and horses ridden by the game go around it.",
                        (*_MOVERS, "cf_horse_avoidance"), _EVERYTHING, 1),
}
# The flags the game's interior collisions use, in plain words (as their names say: the rest keep their names).
TYPE_FLAGS = {
    "cf_map_type_mover": "Stops people and objects", "cf_map_type_horse": "Stops horses",
    "cf_map_type_vehicle": "Stops vehicles", "cf_map_type_weapon": "Stops bullets",
    "cf_cover_type": "Cover can be taken behind it", "cf_map_type_camera": "Stops the camera",
    "cf_stair_slope_type": "Is a stair slope", "cf_horse_avoidance": "Horses go around it",
}
INCLUDE_FLAGS = {
    "cf_ped_type": "People", "cf_ragdoll_type": "People falling (ragdolls)", "cf_horse_type": "Horses",
    "cf_horse_ragdoll_type": "Horses falling", "cf_vehicle_non_bvh_type": "Vehicles", "cf_vehicle_bvh_type": "Vehicles (BVH)",
    "cf_wheel_test": "Wheels", "cf_object_type": "Objects", "cf_projectile_type": "Projectiles (arrows, thrown things)",
    "cf_weapon_test": "Bullets", "cf_explosion_type": "Explosions", "cf_camera_test": "The camera",
    "cf_ai_test": "What characters see and plan (AI)", "cf_script_test": "Scripts' checks", "cf_glass_type": "Glass",
    "cf_plant_type": "Plants", "cf_forklift_forks_type": "Forklift forks",
}


def all_flags():
    from ..ybn.properties import RDRBoundFlags
    return list(RDRBoundFlags.__annotations__)


def flags_on(obj) -> tuple[frozenset, frozenset]:
    names = all_flags()
    return (frozenset(n for n in names if getattr(obj.type_flags, n)), frozenset(n for n in names if getattr(obj.include_flags, n)))


def kind_of(obj) -> str:
    """Which of the game's kinds a part's flags make ("" when none of them: flags set by hand)."""
    on = flags_on(obj)
    return next((kind for kind, (_, _, types, includes, _) in KINDS.items() if on == (frozenset(types), frozenset(includes))), "")


def set_kind(obj, kind: str):
    _, _, types, includes, _ = KINDS[kind]
    for name in all_flags():
        setattr(obj.type_flags, name, name in types)
        setattr(obj.include_flags, name, name in includes)


def parts_chosen(context, collision):
    """The parts of the collision that are selected, themselves or by their mesh."""
    return [obj for obj in flagged(collision) if obj.select_get() or any(child.select_get() for child in obj.children)]


def meshes_of(collision):
    """The collision's meshes: the triangles under its BVHs, and its simple shapes."""
    return [obj for obj in collision.children_recursive if obj.type == "MESH"]


def flagged(collision):
    """The objects that carry the flags: what's directly under the collision (a BVH, a shape)."""
    return [obj for obj in collision.children if obj.sollum_type in BOUND_TYPES]


def without_material(collision):
    return [obj for obj in meshes_of(collision)
            if not any(m is not None and m.sollum_type == MaterialType.COLLISION for m in obj.data.materials)]


def problems_of(obj) -> list[tuple[str, bool]]:
    """What's wrong with a mesh before it's made a collision: (what, whether Apply fixes it)."""
    problems = []
    if not obj.data.polygons:
        problems.append(("has no faces", False))
    if any(abs(s - 1.0) > 1e-4 for s in obj.scale):
        problems.append(("scale not applied", True))
    return problems


def needs_collision(layout, context, guide) -> bool:
    if target_of(context, guide) is not None:
        return False
    text(layout, context, "There's no collision yet: make it in step 2.", icon="INFO")
    return True


def draw_materials(layout, context):
    wm = context.window_manager
    layout.template_list(SOLLUMZ_UL_COLLISION_MATERIALS_LIST.bl_idname, "rf_guide_ybn", wm, "sz_collision_materials",
                         wm, "sz_collision_material_index", rows=5)


# ---- steps


class Meshes(Step):
    label = "Meshes"
    intro = ("A collision is made of meshes nobody sees: keep them simple. Flat floors, plain walls, no small details: "
             "every face is something the game checks against.")

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is not None:
            return DONE, f"{len(meshes_of(target))} mesh(es)"
        meshes = plain_meshes(context)
        if not meshes:
            return TODO, "select"
        wrong = sum(1 for obj in meshes if problems_of(obj))
        return (PROBLEM, f"{wrong} to fix") if wrong else (DONE, f"{len(meshes)} selected")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        meshes = plain_meshes(context)
        if target is not None:
            col = layout.column(align=True)
            for obj in meshes_of(target):
                row = col.row()
                row.label(text=obj.name, icon="MESH_DATA")
                sub = row.row()
                sub.alignment = "RIGHT"
                sub.label(text=f"{len(obj.data.polygons)} faces")
            if meshes:
                layout.operator(REDFORGE_OT_guide_ybn.bl_idname, text=f"Add {len(meshes)} Selected Mesh(es) to It", icon="ADD").action = "ADD"
            return
        if not meshes:
            layout.label(text="No mesh selected", icon="INFO")
            text(layout, context, "For a model's own collision, a copy of its mesh works (Shift D), simplified where it can be.")
            return
        fixable = False
        col = layout.column(align=True)
        for obj in meshes:
            problems = problems_of(obj)
            col.label(text=f"{obj.name}: {len(obj.data.polygons)} faces", icon="ERROR" if problems else "CHECKMARK")
            for what, by_apply in problems:
                text(col, context, what, icon="BLANK1")
                fixable = fixable or by_apply
        if fixable:
            layout.operator("redforge.guide_apply_transforms", icon="CHECKMARK")


class Collision(Step):
    label = "Collision"
    intro = "The meshes become one collision (a Bound Composite): one .ybn file, named after it."

    def status(self, context, guide):
        target = target_of(context, guide)
        return (DONE, target.name) if target is not None else (TODO, "")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        if target is None:
            meshes = plain_meshes(context)
            if not meshes:
                text(layout, context, "Select the meshes first (step 1).", icon="INFO")
                return
            layout.prop(guide, "name")
            name = game_name(guide.name or (context.active_object if context.active_object in meshes else meshes[0]).name)
            layout.label(text=f"It will be: {name}.ybn", icon="FILE")
            text(layout, context, "A model's own collision takes the model's name; an interior's, the interior's. "
                 "A piece of the map's can have any.")
            row = layout.row()
            row.scale_y = 1.4
            row.operator(REDFORGE_OT_guide_ybn.bl_idname, text="Create the Collision", icon="MOD_WIREFRAME").action = "CREATE"
            return
        layout.prop(target, "name", text="Name")
        layout.label(text="Add a simple shape", icon="ADD")
        text(layout, context, "Much lighter for the game than a mesh, where one fits: a box for a crate or a wall, a "
             "capsule for a post. It's made at the 3D cursor: move and scale it like any object.")
        grid = layout.grid_flow(columns=2, align=True)
        for shape, label, icon in SHAPES:
            grid.operator(REDFORGE_OT_guide_ybn_shape.bl_idname, text=label, icon=icon).shape = shape.value
        row = layout.row(align=True)
        if context.scene.sollumz_show_collisions:
            row.operator(SOLLUMZ_OT_HIDE_COLLISIONS.bl_idname, icon="HIDE_OFF")
        else:
            row.operator(SOLLUMZ_OT_SHOW_COLLISIONS.bl_idname, icon="HIDE_ON")
        row.operator(REDFORGE_OT_guide_ybn.bl_idname, text="Make Another", icon="ADD").action = "NEW"


class Materials(Step):
    label = "Materials"
    intro = ("What each surface is: wood, stone, mud. It sets the footstep sounds, the bullet marks and dust, "
             "and how slippery it is.")

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        bare = without_material(target)
        if bare:
            return PROBLEM, f"{len(bare)} without"
        names = {m.name.split(".")[0] for obj in meshes_of(target) for m in obj.data.materials if m is not None}
        if not names:
            return TODO, "no mesh"
        return DONE, next(iter(names)).lower() if len(names) == 1 else f"{len(names)} materials"

    def draw(self, layout, context, guide):
        if needs_collision(layout, context, guide):
            return
        target = target_of(context, guide)
        meshes = meshes_of(target)
        col = layout.column(align=True)
        for obj in meshes:
            row = col.row()
            names = [m.name for m in obj.data.materials if m is not None]
            row.label(text=obj.name, icon="CHECKMARK" if names else "ERROR")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.label(text=", ".join(names) or "none")
        draw_materials(layout, context)
        chosen = [obj for obj in meshes if obj.select_get()]
        col = layout.column(align=True)
        col.scale_y = 1.2
        col.operator(REDFORGE_OT_guide_ybn.bl_idname, icon="MATERIAL",
                     text=f"Use It on the {len(chosen)} Selected" if chosen else "Use It on the Whole Collision").action = "MATERIAL"
        row = col.row(align=True)
        row.enabled = bool(chosen)
        row.operator(REDFORGE_OT_guide_ybn.bl_idname, text="Add It as a Second Material", icon="ADD").action = "SLOT"
        text(layout, context, "One mesh with several: add each here, then give it to faces in Edit Mode like any material (Material tab, Assign).")


class Flags(Step):
    label = "Flags"
    intro = ("What each part of the collision is solid for: the most important thing about it after its shape. "
             "The game's own collisions only use the few kinds below.")

    def status(self, context, guide):
        target = target_of(context, guide)
        if target is None:
            return TODO, ""
        parts = flagged(target)
        none = sum(1 for obj in parts if not flags_on(obj)[0])
        if none:
            return PROBLEM, f"{none} without flags"
        kinds = {kind_of(obj) for obj in parts}
        if len(kinds) == 1:
            kind = next(iter(kinds))
            return DONE, KINDS[kind][0].lower() if kind else "set by hand"
        return DONE, f"{len(kinds)} kinds"

    def draw(self, layout, context, guide):
        if needs_collision(layout, context, guide):
            return
        target = target_of(context, guide)
        parts = flagged(target)
        chosen = parts_chosen(context, target)
        col = layout.column(align=True)
        for obj in parts:
            row = col.row(align=True)
            left = row.row(align=True)
            left.alignment = "LEFT"
            kind = kind_of(obj)
            bare = not flags_on(obj)[0]
            left.operator(REDFORGE_OT_guide_ybn_select.bl_idname, text=obj.name, icon="ERROR" if bare else "CHECKMARK",
                          emboss=obj in chosen, depress=obj in chosen).object = obj.name
            right = row.row()
            right.alignment = "RIGHT"
            right.label(text="no flags: it does nothing" if bare else (KINDS[kind][0] if kind else "set by hand"))

        layout.separator()
        layout.label(text=f"Make the {len(chosen)} selected part(s):" if chosen else "Make the whole collision:", icon="MOD_PHYSICS")
        current = {kind_of(obj) for obj in (chosen or parts)}
        for kind, (name, what, _, _, count) in KINDS.items():
            box = layout.box()
            box.operator(REDFORGE_OT_guide_ybn_kind.bl_idname, text=name, depress=current == {kind}).kind = kind
            text(box, context, f"{what} ({count} of the 179 parts of the game's interior collisions.)")

        layout.separator()
        layout.prop(guide, "flags_shown", icon="OPTIONS", toggle=True)
        if not guide.flags_shown:
            return
        part = chosen[0] if chosen else (parts[0] if parts else None)
        if part is None:
            return
        layout.label(text=part.name, icon="OBJECT_DATA")
        if len(chosen) > 1:
            text(layout, context, "Several parts are selected: these are the first one's. A kind above sets them all.", icon="INFO")
        for title, flags, labels in (("What it is", part.type_flags, TYPE_FLAGS), ("What is checked against it", part.include_flags, INCLUDE_FLAGS)):
            box = layout.box()
            box.label(text=title)
            col = box.column(align=True)
            for name, label in labels.items():
                col.prop(flags, name, text=label)
            col = box.column(align=True)
            col.label(text="Not used by the game's interior collisions:")
            for name in all_flags():
                if name not in labels:
                    col.prop(flags, name, text=name[3:].replace("_", " ").capitalize())


class Export(Step):
    label = "Check & Export"
    intro = "What's left to fix, then the file: to a folder, or straight into RedForge's project."

    def issues(self, context, guide) -> list[tuple[int, str]]:
        target = target_of(context, guide)
        issues = []
        for index, step in enumerate(YbnFlow.steps[:-1]):
            state, note = step.status(context, guide)
            if state in (PROBLEM, TODO):
                issues.append((index, f"{step.label}: {note}" if note else f"{step.label}: not done"))
        if target is not None:
            if not meshes_of(target):
                issues.append((0, "The collision has no mesh or shape"))
            if target.name != game_name(target.name):
                issues.append((1, f"The name {target.name} will be written as {game_name(target.name)}"))
        return issues

    def status(self, context, guide):
        issues = self.issues(context, guide)
        return (PROBLEM, f"{len(issues)} to fix") if issues else (TODO, "ready")

    def draw(self, layout, context, guide):
        target = target_of(context, guide)
        issues = self.issues(context, guide)
        for index, what in issues:
            row = layout.row()
            text(row, context, what, icon="ERROR")
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.operator(core.REDFORGE_OT_guide_step.bl_idname, text="Fix").index = index
        if target is None:
            return
        if not issues:
            layout.label(text="Nothing to fix", icon="CHECKMARK")
        from ..redforge import link
        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.enabled = not any(index < 3 for index, _ in issues)
        row = col.row(align=True)
        row.enabled = link.connected()
        row.operator(REDFORGE_OT_guide_ybn.bl_idname, text="Send to RedForge", icon="EXPORT").action = "SEND"
        col.operator(REDFORGE_OT_guide_ybn.bl_idname, text="Export to the Folder", icon="FILE_FOLDER").action = "EXPORT"
        if not link.connected():
            layout.label(text="RedForge isn't running", icon="UNLINKED")
        layout.prop(context.scene, "sollumz_export_path", text="Folder")
        text(layout, context, "The game loads a collision that a map (.ymap) lists, or that an archetype names as its physics dictionary.")


@flow
class YbnFlow(Flow):
    id = "ybn"
    label = "Collision (YBN)"
    icon = "MOD_WIREFRAME"
    summary = "A collision of its own: a piece of ground, an invisible wall, what an interior is made on. From your meshes to the .ybn"
    steps = (Meshes(), Collision(), Materials(), Flags(), Export())

    def adopt(self, context):
        obj = context.active_object
        if obj is None or not obj.select_get():
            return None
        while obj.parent is not None:
            obj = obj.parent
        return obj if obj.sollum_type == SollumType.BOUND_COMPOSITE else None  # (not one inside a model: that's the model's)


# ---- operators


class REDFORGE_OT_guide_ybn(GuideOperator, bpy.types.Operator):
    """The Guide's collision"""
    bl_idname = "redforge.guide_ybn"
    bl_label = "Collision"
    action: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return {
            "CREATE": "Make one collision of the selected meshes, with the material picked in step 3's list, solid for everything (step 4 changes that)",
            "ADD": "Make the selected meshes part of the collision",
            "NEW": "Leave this collision as it is and start another one from the first step",
            "MATERIAL": "Give the collision, or its selected meshes, the material picked in the list, in place of what they have",
            "SLOT": "Add the material picked in the list to the selected meshes, next to what they have, to give it to some of their faces",
            "EXPORT": "Write the collision's .ybn.xml in the folder",
            "SEND": "Put the collision in RedForge's project",
        }.get(properties.action, "")

    def run(self, context, guide, target):
        return getattr(self, self.action.lower())(context, guide, target)

    def to_bvh(self, context, collision, meshes):
        """Each mesh under a BVH of its own under the collision, where it was."""
        game = context.scene.sollum_game_type
        wm = context.window_manager
        worlds = [obj.matrix_world.copy() for obj in meshes]
        for obj in meshes:
            bvh = convert_obj_to_bvh(obj, game)
            bvh.parent = collision
            set_kind(bvh, "solid")
        context.view_layer.update()
        for obj in meshes:
            obj.parent.matrix_world = collision.matrix_world
        context.view_layer.update()
        for obj, world in zip(meshes, worlds):
            obj.matrix_world = world
            obj.data.materials.clear()
            obj.data.materials.append(create_collision_material_from_index(wm.sz_collision_material_index, game))

    def create(self, context, guide, target):
        meshes = plain_meshes(context)
        if not meshes:
            raise RuntimeError("No mesh selected")
        first = context.active_object if context.active_object in meshes else meshes[0]
        name = game_name(guide.name or first.name)
        if not name:
            raise RuntimeError("The collision needs a name")
        with context.temp_override(collection=first.users_collection[0]):
            collision = convert_objs_to_single_composite([], SollumType.BOUND_GEOMETRYBVH, context.scene.sollum_game_type)
            self.to_bvh(context, collision, meshes)
        collision.name = name
        guide.target = collision
        guide.name = ""
        guide.step = 2
        select_only(context, [collision])
        return f"{name} is a collision of {len(meshes)} mesh(es)"

    def add(self, context, guide, target):
        meshes = plain_meshes(context)
        with context.temp_override(collection=target.users_collection[0]):
            self.to_bvh(context, target, meshes)
        return f"{len(meshes)} mesh(es) added to {target.name}"

    def new(self, context, guide, target):
        guide.target = None
        guide.name = ""
        guide.step = 0
        select_only(context, [])

    def material(self, context, guide, target, replace=True):
        game = context.scene.sollum_game_type
        index = context.window_manager.sz_collision_material_index
        chosen = [obj for obj in meshes_of(target) if obj.select_get()]
        if not replace and not chosen:
            raise RuntimeError("Select the meshes of the collision that get a second material")
        for obj in chosen or meshes_of(target):
            if replace:
                obj.data.materials.clear()
            obj.data.materials.append(create_collision_material_from_index(index, game))
        return f"{len(chosen or meshes_of(target))} mesh(es)"

    def slot(self, context, guide, target):
        return self.material(context, guide, target, replace=False)

    def export(self, context, guide, target):
        scene = context.scene
        folder = bpy.path.abspath(scene.sollumz_export_path)
        if not scene.sollumz_export_path or not os.path.isdir(folder):
            raise RuntimeError("Choose the folder to export to")
        settings = get_export_settings(context)
        wanted = {"limit_to_selected": True, "export_with_ytyp": False}
        before = {name: getattr(settings, name) for name in wanted}
        changed = [name for name in wanted if before[name] != wanted[name]]  # (setting one saves the preferences)
        select_only(context, [target])
        try:
            for name in changed:
                setattr(settings, name, wanted[name])
            if "FINISHED" not in bpy.ops.sollumz.export_assets(directory=folder, direct_export=True):
                raise RuntimeError("The collision wasn't exported: see the Info log")
        finally:
            for name in changed:
                setattr(settings, name, before[name])
        return f"Exported {game_name(target.name)}.ybn.xml"

    def send(self, context, guide, target):
        from ..redforge import bridge, link
        from ..ybn.ybnexport import export_ybn
        name = f"{game_name(target.name)}.ybn"
        folder = os.path.join(tempfile.gettempdir(), "RedForge", "Blender", "send", name)
        shutil.rmtree(folder, ignore_errors=True)
        os.makedirs(folder)
        xml = os.path.join(folder, f"{name}.xml")
        if not export_ybn(target, xml):
            raise RuntimeError("The collision wasn't exported: see the Info log")
        link.request(bridge.prefs(context).redforge_port, "import", xml=xml, file=name)
        return f"Sent to RedForge: {name}"


class REDFORGE_OT_guide_ybn_shape(GuideOperator, bpy.types.Operator):
    """Add this simple shape to the collision, at the 3D cursor, with the material picked in step 3's list"""
    bl_idname = "redforge.guide_ybn_shape"
    bl_label = "Add a Shape"
    shape: StringProperty()

    def run(self, context, guide, target):
        game = context.scene.sollum_game_type
        wm = context.window_manager
        with context.temp_override(collection=target.users_collection[0]):
            obj = create_bound_shape(SollumType(self.shape))
        obj.sollum_game_type = game
        obj.parent = target
        context.view_layer.update()
        obj.matrix_world.translation = context.scene.cursor.location
        set_kind(obj, "solid")
        if obj.type == "MESH" and not obj.data.materials:
            obj.data.materials.append(create_collision_material_from_index(wm.sz_collision_material_index, game))
        select_only(context, [obj])
        return f"{obj.name} added"


class REDFORGE_OT_guide_ybn_select(bpy.types.Operator):
    """Select this part of the collision, to set its flags. Shift-click parts in the viewport to select several"""
    bl_idname = "redforge.guide_ybn_select"
    bl_label = "Select the Part"
    bl_options = {"INTERNAL"}
    object: StringProperty()

    def execute(self, context):
        obj = context.scene.objects.get(self.object)
        if obj is None:
            return {"CANCELLED"}
        select_only(context, [obj])
        return {"FINISHED"}


class REDFORGE_OT_guide_ybn_kind(GuideOperator, bpy.types.Operator):
    """Give the selected parts of the collision, or all of it when none is selected, the flags of this kind"""
    bl_idname = "redforge.guide_ybn_kind"
    bl_label = "Set the Kind"
    kind: StringProperty()

    @classmethod
    def description(cls, context, properties):
        kind = KINDS.get(properties.kind)
        return kind[1] if kind else ""

    def run(self, context, guide, target):
        parts = parts_chosen(context, target) or flagged(target)
        for obj in parts:
            set_kind(obj, self.kind)
        return f"{KINDS[self.kind][0]}: {len(parts)} part(s)"
