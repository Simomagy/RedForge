# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


# RedForge for Blender: a fork of Sollumz RDR (Skylumz, Colton and alexguirre) for Red Dead Redemption 2 / RedM only,
# linked to RedForge. Blender 5.3 or newer (the manifest has the minimum: Blender checks it).


def reload_sollumz_modules():
    import sys

    print("Reloading Sollumz modules")

    # Remove the packages imported in this module from the scope, so they are loaded again when imported below
    global auto_load, sollumz_tool, sollumz_debug, bpy
    del sollumz_tool
    del sollumz_debug
    del auto_load
    del bpy

    # Remove from `sys.modules` all Sollumz modules, so they are loaded again by auto_load
    sz_module_prefix = f"{__package__}."
    module_names = list(sys.modules.keys())
    for name in module_names:
        if name.startswith(sz_module_prefix):
            del sys.modules[name]


if "auto_load" in locals():
    # If an imported name already exists before imports, it means that the addon has been reloaded by Blender.
    # Blender only reloads the main __init__.py file, so we reload all our modules now.
    reload_sollumz_modules()


# These need to be here, not at the top of the file, to handle reload
from . import sollumz_tool  # noqa: E402, F811
from . import sollumz_debug  # noqa: E402, F811
from . import auto_load  # noqa: E402, F811
import bpy  # noqa: E402, F811


sollumz_debug.init_debug()  # first in case we need to debug initialization code
auto_load.init()


def register():
    check_single_sollumz_instance()

    auto_load.register()

    # WorkSpaceTools need to be registered after normal modules so the keymaps
    # detect the registed operators
    sollumz_tool.register_tools()


def unregister():
    sollumz_tool.unregister_tools()

    auto_load.unregister()


def check_single_sollumz_instance():
    if hasattr(bpy.types.Object, "sollum_type"):
        raise_fatal_error(
            title="Sollumz Is Enabled Too",
            message="RedForge for Blender replaces Sollumz and Sollumz RDR: disable them in Preferences > Add-ons, then enable it again."
        )


def raise_fatal_error(title: str, message: str):
    """Fatal error that doesn't allow the add-on to be initialized."""

    def _draw_error_popup(self, context):
        self.layout.label(text=message)

    def _show_error_popup():
        bpy.context.window_manager.popup_menu(_draw_error_popup, title=title, icon="ERROR")

    bpy.app.timers.register(_show_error_popup, first_interval=0.0)

    # Raise an error so Blender doesn't actually enable the add-on
    raise ImportError(f"{title}. \n{message}")
