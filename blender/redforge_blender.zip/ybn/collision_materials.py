import bpy
from bpy.types import (
    Material
)
from ..shared.shader_expr.builtins import (
    bsdf_diffuse,
    vec,
)
from ..shared.shader_expr import (
    expr,
    compile_to_material,
)
from ..sollumz_properties import MaterialType, SollumzGame
from typing import NamedTuple
from .. import logger


class CollisionMaterial(NamedTuple):
    name: str
    ui_name: str
    color: tuple[int, int, int]
    density: float


rdr_collisionmats = [
    CollisionMaterial("DEFAULT", "Default", (255, 0, 255), 1750.0),
    CollisionMaterial("CONCRETE", "Concrete", (145, 145, 145), 7850.5),
    CollisionMaterial("CONCRETE_PAVEMENT", "Concrete Pavement", (200, 165, 130), 7850.5),
    CollisionMaterial("TARMAC", "Tarmac", (90, 90, 90), 6300.0),
    CollisionMaterial("ROCK", "Rock", (185, 185, 185), 7000.0),
    CollisionMaterial("ROCK_MOSSY", "Rock Mossy", (185, 185, 185), 7000.0),
    CollisionMaterial("STONE", "Stone", (185, 185, 185), 7000.0),
    CollisionMaterial("COBBLESTONE", "Cobblestone", (185, 185, 185), 7000.0),
    CollisionMaterial("COBBLESTONE_DIRT", "Cobblestone Dirt", (180, 175, 165), 7000.0),
    CollisionMaterial("BRICK", "Brick", (195, 95, 30), 7000.0),
    CollisionMaterial("BRICK_PAVEMENT", "Brick Pavement", (200, 165, 130), 7000.0),
    CollisionMaterial("MARBLE", "Marble", (195, 155, 145), 8970.5),
    CollisionMaterial("SANDSTONE_SOLID", "Sandstone Solid", (215, 195, 150), 8130.5),
    CollisionMaterial("SANDSTONE_BRITTLE", "Sandstone Brittle", (205, 180, 120), 5075.0),
    CollisionMaterial("SAND_COMPACT", "Sand Compact", (250, 240, 220), 5950.0),
    CollisionMaterial("SAND_WET", "Sand Wet", (190, 185, 165), 6727.0),
    CollisionMaterial("SAND_DRY_DEEP", "Sand Dry Deep", (120, 110, 95), 6727.0),
    CollisionMaterial("SAND_WET_DEEP", "Sand Wet Deep", (110, 100, 85), 6727.0),
    CollisionMaterial("QUICKSAND", "Quicksand", (130, 120, 105), 6727.0),
    CollisionMaterial("ALGAE", "Algae", (130, 120, 105), 6727.0),
    CollisionMaterial("ALGAE_THICK", "Algae Thick", (130, 120, 105), 6727.0),
    CollisionMaterial("TAR_PIT", "Tar Pit", (80, 80, 80), 3573.5),
    CollisionMaterial("ICE", "Ice", (200, 250, 255), 3216.5),
    CollisionMaterial("SNOW_COMPACT", "Snow Compact", (255, 255, 255), 1683.5),
    CollisionMaterial("SNOW_DEEP", "Snow Deep", (255, 255, 255), 560.0),
    CollisionMaterial("SLUSH", "Slush", (235, 255, 255), 6727.0),
    CollisionMaterial("GRAVEL_SMALL", "Gravel Small", (235, 235, 235), 6727.0),
    CollisionMaterial("GRAVEL_LARGE", "Gravel Large", (235, 235, 235), 5887.0),
    CollisionMaterial("GRAVEL_WET", "Gravel Wet", (235, 215, 215), 6727.0),
    CollisionMaterial("GRAVEL_DEEP", "Gravel Deep", (235, 225, 225), 6727.0),
    CollisionMaterial("GRAVEL_MUDDY", "Gravel Muddy", (235, 215, 215), 6727.0),
    CollisionMaterial("GRAVEL_MUDDY_DEEP", "Gravel Muddy Deep", (225, 225, 225), 6727.0),
    CollisionMaterial("GRAVEL_DIRT", "Gravel Dirt", (245, 235, 235), 6727.0),
    CollisionMaterial("GRAVEL_GRASS", "Gravel Grass", (235, 255, 235), 6727.0),
    CollisionMaterial("DIRT_TRACK", "Dirt Track", (175, 160, 140), 4550.0),
    CollisionMaterial("DIRT_TRACK_DEEP", "Dirt Track Deep", (165, 150, 130), 4550.0),
    CollisionMaterial("DIRT_GRASS", "Dirt Grass", (165, 180, 130), 4550.0),
    CollisionMaterial("MUD_HARD", "Mud Hard", (115, 105, 85), 5327.0),
    CollisionMaterial("MUD_POTHOLE", "Mud Pothole", (105, 95, 75), 4200.0),
    CollisionMaterial("MUD_SOFT", "Mud Soft", (105, 95, 75), 6055.0),
    CollisionMaterial("MUD_UNDERWATER", "Mud Underwater", (75, 65, 50), 6055.0),
    CollisionMaterial("MUD_DEEP", "Mud Deep", (105, 95, 75), 6055.0),
    CollisionMaterial("MARSH", "Marsh", (105, 155, 75), 6055.0),
    CollisionMaterial("MARSH_DEEP", "Marsh Deep", (95, 145, 65), 6055.0),
    CollisionMaterial("SOIL", "Soil", (105, 115, 75), 5047.0),
    CollisionMaterial("SOIL_DEEP", "Soil Deep", (95, 105, 65), 5047.0),
    CollisionMaterial("CLAY_HARD", "Clay Hard", (160, 160, 160), 6111.0),
    CollisionMaterial("CLAY_SOFT", "Clay Soft", (160, 160, 160), 3755.5),
    CollisionMaterial("ASH", "Ash", (110, 110, 110), 3755.5),
    CollisionMaterial("COAL", "Coal", (30, 30, 30), 5887.0),
    CollisionMaterial("MANURE", "Manure", (110, 70, 70), 3755.5),
    CollisionMaterial("MOSS", "Moss", (110, 190, 110), 3755.5),
    CollisionMaterial("MOSS_DEEP", "Moss Deep", (110, 190, 110), 3755.5),
    CollisionMaterial("GRASS_DEAD", "Grass Dead", (190, 205, 150), 4900.0),
    CollisionMaterial("GRASS_LUSH", "Grass Lush", (130, 235, 75), 4900.0),
    CollisionMaterial("GRASS_LONG", "Grass Long", (130, 205, 75), 4900.0),
    CollisionMaterial("GRASS", "Grass", (130, 205, 75), 5600.0),
    CollisionMaterial("GRASS_SHORT", "Grass Short", (130, 205, 75), 5950.0),
    CollisionMaterial("HAY", "Hay", (240, 205, 125), 5950.0),
    CollisionMaterial("BUSHES", "Bushes", (85, 160, 30), 525.0),
    CollisionMaterial("SPARSE_BUSHES", "Sparse Bushes", (85, 160, 30), 212.5),
    CollisionMaterial("DENSE_BUSHES", "Dense Bushes", (85, 160, 30), 1050.0),
    CollisionMaterial("TWIGS", "Twigs", (90, 100, 50), 700.0),
    CollisionMaterial("PINE_NEEDLES", "Pine Needles", (90, 100, 60), 350.0),
    CollisionMaterial("LEAVES_DRY", "Leaves Dry", (70, 100, 50), 350.0),
    CollisionMaterial("LEAVES_TOBACCO", "Leaves Tobacco", (70, 100, 50), 350.0),
    CollisionMaterial("LEAVES", "Leaves", (70, 100, 50), 350.0),
    CollisionMaterial("LEAVES_MAPLE", "Leaves Maple", (70, 100, 50), 350.0),
    CollisionMaterial("LEAVES_OAK", "Leaves Oak", (70, 100, 50), 350.0),
    CollisionMaterial("LEAVES_FICUS", "Leaves Ficus", (70, 100, 50), 350.0),
    CollisionMaterial("WOODCHIPS", "Woodchips", (115, 100, 70), 1820.0),
    CollisionMaterial("TREE_PINE", "Tree Pine", (115, 100, 70), 350.0),
    CollisionMaterial("TREE_PINE_SNOW", "Tree Pine Snow", (145, 130, 100), 350.0),
    CollisionMaterial("FLOWERS", "Flowers", (130, 205, 75), 350.0),
    CollisionMaterial("CROP_HUSK", "Crop Husk", (240, 205, 125), 350.0),
    CollisionMaterial("TREE_BARK", "Tree Bark", (115, 100, 70), 840.0),
    CollisionMaterial("CACTUS", "Cactus", (110, 195, 55), 350.0),
    CollisionMaterial("METAL_SOLID_SMALL", "Metal Solid Small", (155, 180, 190), 24500.0),
    CollisionMaterial("METAL_SOLID_MEDIUM", "Metal Solid Medium", (155, 180, 190), 28000.0),
    CollisionMaterial("METAL_SOLID_LARGE", "Metal Solid Large", (155, 180, 190), 31500.0),
    CollisionMaterial("METAL_HOLLOW_SMALL", "Metal Hollow Small", (155, 180, 190), 1750.0),
    CollisionMaterial("METAL_HOLLOW_MEDIUM", "Metal Hollow Medium", (155, 180, 190), 2100.0),
    CollisionMaterial("METAL_HOLLOW_LARGE", "Metal Hollow Large", (155, 180, 190), 2450.0),
    CollisionMaterial("METAL_CHAINLINK_SMALL", "Metal Chainlink Small", (155, 180, 190), 3500.0),
    CollisionMaterial("METAL_CORRUGATED_IRON", "Metal Corrugated Iron", (155, 180, 190), 21000.0),
    CollisionMaterial("METAL_GRILLE", "Metal Grille", (155, 180, 190), 3500.0),
    CollisionMaterial("METAL_RAILING", "Metal Railing", (155, 180, 190), 4200.0),
    CollisionMaterial("METAL_RAILING_TRAM", "Metal Railing Tram", (155, 180, 190), 4200.0),
    CollisionMaterial("METAL_DUCT", "Metal Duct", (155, 180, 190), 1750.0),
    CollisionMaterial("METAL_PENETRABLE", "Metal Penetrable", (155, 180, 190), 1750.0),
    CollisionMaterial("METAL_BARS", "Metal Bars", (155, 180, 190), 28000.0),
    CollisionMaterial("WOOD_ROOF", "Wood Roof", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_BURNING", "Wood Burning", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_BURNT", "Wood Burnt", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_CHIPS", "Wood Chips", (115, 100, 70), 1820.0),
    CollisionMaterial("WOOD_SOLID_SMALL", "Wood Solid Small", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_SOLID_MEDIUM", "Wood Solid Medium", (155, 130, 95), 2100.0),
    CollisionMaterial("WOOD_SOLID_LARGE", "Wood Solid Large", (155, 130, 95), 2852.5),
    CollisionMaterial("WOOD_SOLID_POLISHED", "Wood Solid Polished", (155, 130, 95), 2800.0),
    CollisionMaterial("WOOD_FLOOR_DUSTY", "Wood Floor Dusty", (165, 145, 110), 2100.0),
    CollisionMaterial("WOOD_HOLLOW_SMALL", "Wood Hollow Small", (170, 150, 125), 350.0),
    CollisionMaterial("WOOD_HOLLOW_MEDIUM", "Wood Hollow Medium", (170, 150, 125), 700.0),
    CollisionMaterial("WOOD_HOLLOW_LARGE", "Wood Hollow Large", (170, 150, 125), 1050.0),
    CollisionMaterial("WOOD_OLD_CREAKY", "Wood Old Creaky", (155, 130, 95), 2100.0),
    CollisionMaterial("WOOD_LATTICE", "Wood Lattice", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_PENETRABLE", "Wood Penetrable", (170, 150, 125), 350.0),
    CollisionMaterial("CERAMIC", "Ceramic", (220, 210, 195), 9695.0),
    CollisionMaterial("ROOF_TILE", "Roof Tile", (220, 210, 195), 7000.0),
    CollisionMaterial("TARPAULIN", "Tarpaulin", (250, 100, 100), 2800.0),
    CollisionMaterial("PLASTIC_CLEAR", "Plastic Clear", (255, 250, 210), 3500.0),
    CollisionMaterial("PLASTIC_HOLLOW_CLEAR", "Plastic Hollow Clear", (255, 250, 210), 875.0),
    CollisionMaterial("PLASTIC_HIGH_DENSITY_CLEAR", "Plastic High Density Clear", (255, 250, 210), 21000.0),
    CollisionMaterial("RUBBER", "Rubber", (70, 70, 70), 4200.0),
    CollisionMaterial("CARPET_SOLID", "Carpet Solid", (250, 100, 100), 1050.0),
    CollisionMaterial("CARPET_SOLID_DUSTY", "Carpet Solid Dusty", (250, 100, 100), 1050.0),
    CollisionMaterial("CLOTH", "Cloth", (230, 235, 235), 875.0),
    CollisionMaterial("CLOTH_SACK", "Cloth Sack", (230, 235, 235), 875.0),
    CollisionMaterial("PLASTER_SOLID", "Plaster Solid", (225, 225, 225), 2971.5),
    CollisionMaterial("PLASTER_BRITTLE", "Plaster Brittle", (225, 225, 225), 2971.5),
    CollisionMaterial("PLASTER_PENETRABLE", "Plaster Penetrable", (225, 225, 225), 2971.5),
    CollisionMaterial("PAPER", "Paper", (230, 225, 220), 4203.5),
    CollisionMaterial("FEATHER_PILLOW", "Feather Pillow", (230, 230, 230), 192.5),
    CollisionMaterial("LEATHER", "Leather", (150, 100, 85), 3307.5),
    CollisionMaterial("SLATTED_BLINDS", "Slatted Blinds", (170, 150, 125), 8750.0),
    CollisionMaterial("UPHOLSTRY", "Upholstry", (250, 100, 100), 8750.0),
    CollisionMaterial("CURTAINS", "Curtains", (250, 100, 100), 8750.0),
    CollisionMaterial("WICKER", "Wicker", (180, 130, 105), 8750.0),
    CollisionMaterial("TERRACOTTA", "Terracotta", (220, 180, 105), 8750.0),
    CollisionMaterial("PORCELAIN", "Porcelain", (220, 210, 195), 8750.0),
    CollisionMaterial("TILE", "Tile", (220, 210, 195), 8750.0),
    CollisionMaterial("GRAIN_SACK", "Grain Sack", (180, 140, 115), 8750.0),
    CollisionMaterial("SAND_BAG", "Sand Bag", (180, 140, 115), 8750.0),
    CollisionMaterial("PAINT_CAN", "Paint Can", (155, 180, 190), 8750.0),
    CollisionMaterial("TRASH", "Trash", (230, 225, 220), 8750.0),
    CollisionMaterial("GLASS_SHOOT_THROUGH", "Glass Shoot Through", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BOTTLE_SHOT", "Glass Bottle Shot", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BOTTLE_MEDICINE", "Glass Bottle Medicine", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BOTTLE_LIQUOR", "Glass Bottle Liquor", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BOTTLE_JUG", "Glass Bottle Jug", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BULLETPROOF", "Glass Bulletproof", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_BULLETPROOF_SEE_THROUGH", "Glass Bulletproof See Through", (205, 240, 255), 8750.0),
    CollisionMaterial("GLASS_OPAQUE", "Glass Opaque", (205, 240, 255), 8750.0),
    CollisionMaterial("CAR_METAL", "Car Metal", (255, 255, 255), 3363.5),
    CollisionMaterial("CAR_SOFTTOP", "Car Softtop", (250, 100, 100), 1750.0),
    CollisionMaterial("CAR_SOFTTOP_CLEAR", "Car Softtop Clear", (250, 100, 100), 1750.0),
    CollisionMaterial("CAR_GLASS_WEAK", "Car Glass Weak", (210, 245, 245), 8750.0),
    CollisionMaterial("CAR_GLASS_MEDIUM", "Car Glass Medium", (210, 245, 245), 8750.0),
    CollisionMaterial("CAR_GLASS_STRONG", "Car Glass Strong", (210, 245, 245), 8750.0),
    CollisionMaterial("CAR_GLASS_BULLETPROOF", "Car Glass Bulletproof", (210, 245, 245), 8750.0),
    CollisionMaterial("CAR_GLASS_OPAQUE", "Car Glass Opaque", (210, 245, 245), 8750.0),
    CollisionMaterial("CAR_ENGINE", "Car Engine", (255, 255, 255), 3363.5),
    CollisionMaterial("VEH_WOOD", "Veh Wood", (155, 130, 95), 8750.0),
    CollisionMaterial("WEAPON_WOOD", "Weapon Wood", (155, 130, 95), 1400.0),
    CollisionMaterial("WEAPON_METAL", "Weapon Metal", (155, 180, 190), 24500.0),
    CollisionMaterial("WATER_SHALLOW", "Water Shallow", (55, 145, 230), 3573.5),
    CollisionMaterial("WATER", "Water", (55, 145, 230), 3573.5),
    CollisionMaterial("BLOOD", "Blood", (205, 5, 5), 3573.5),
    CollisionMaterial("OIL", "Oil", (80, 65, 65), 3573.5),
    CollisionMaterial("PETROL", "Petrol", (70, 100, 120), 3573.5),
    CollisionMaterial("PUDDLE", "Puddle", (55, 145, 230), 3573.5),
    CollisionMaterial("PUDDLE_ANKLE", "Puddle Ankle", (55, 145, 230), 3573.5),
    CollisionMaterial("WATER_ANKLE", "Water Ankle", (55, 145, 230), 3573.5),
    CollisionMaterial("WATER_SHIN", "Water Shin", (55, 145, 230), 3573.5),
    CollisionMaterial("WATER_KNEE", "Water Knee", (55, 145, 230), 3573.5),
    CollisionMaterial("FRESH_MEAT", "Fresh Meat", (255, 55, 20), 4200.0),
    CollisionMaterial("DRIED_MEAT", "Dried Meat", (185, 100, 85), 4200.0),
    CollisionMaterial("FURRY_MEAT", "Furry Meat", (185, 100, 85), 4200.0),
    CollisionMaterial("PELT_FUR", "Pelt Fur", (185, 130, 95), 4200.0),
    CollisionMaterial("LEATHER_HIDE", "Leather Hide", (150, 100, 85), 4200.0),
    CollisionMaterial("BONES", "Bones", (225, 220, 200), 4200.0),
    CollisionMaterial("EMISSIVE_GLASS", "Emissive Glass", (205, 240, 255), 8750.0),
    CollisionMaterial("EMISSIVE_PLASTIC", "Emissive Plastic", (255, 250, 210), 3500.0),
    CollisionMaterial("VFX_METAL_ELECTRIFIED", "Vfx Metal Electrified", (155, 180, 190), 2100.0),
    CollisionMaterial("VFX_METAL_WATER_TOWER", "Vfx Metal Water Tower", (155, 180, 190), 2100.0),
    CollisionMaterial("VFX_WOOD_BEER_BARREL", "Vfx Wood Beer Barrel", (155, 130, 95), 1400.0),
    CollisionMaterial("VFX_METAL_STEAM", "Vfx Metal Steam", (155, 180, 190), 2100.0),
    CollisionMaterial("VFX_METAL_FLAME", "Vfx Metal Flame", (155, 180, 190), 2100.0),
    CollisionMaterial("PHYS_NO_FRICTION", "Phys No Friction", (0, 0, 0), 1750.0),
    CollisionMaterial("PHYS_CASTER", "Phys Caster", (0, 0, 0), 1750.0),
    CollisionMaterial("PHYS_CAR_VOID", "Phys Car Void", (0, 0, 0), 1750.0),
    CollisionMaterial("PHYS_PED_CAPSULE", "Phys Ped Capsule", (255, 55, 20), 1750.0),
    CollisionMaterial("PHYS_MACHINERY", "Phys Machinery", (0, 0, 0), 1750.0),
    CollisionMaterial("PHYS_BARBED_WIRE", "Phys Barbed Wire", (0, 0, 0), 1750.0),
    CollisionMaterial("PHYS_BLOCKER", "Phys Blocker", (0, 0, 0), 10.0),
    CollisionMaterial("PHYS_DYNAMIC_COVER_BOUND", "Phys Dynamic Cover Bound", (0, 0, 0), 1750.0),
    CollisionMaterial("BUTTOCKS", "Buttocks", (255, 55, 20), 350.0),
    CollisionMaterial("THIGH_LEFT", "Thigh Left", (185, 100, 85), 350.0),
    CollisionMaterial("SHIN_LEFT", "Shin Left", (185, 100, 85), 350.0),
    CollisionMaterial("FOOT_LEFT", "Foot Left", (185, 100, 85), 350.0),
    CollisionMaterial("THIGH_RIGHT", "Thigh Right", (185, 100, 85), 350.0),
    CollisionMaterial("SHIN_RIGHT", "Shin Right", (185, 100, 85), 350.0),
    CollisionMaterial("FOOT_RIGHT", "Foot Right", (185, 100, 85), 350.0),
    CollisionMaterial("SPINE0", "Spine0", (255, 55, 20), 350.0),
    CollisionMaterial("SPINE1", "Spine1", (255, 55, 20), 350.0),
    CollisionMaterial("SPINE2", "Spine2", (255, 55, 20), 350.0),
    CollisionMaterial("SPINE3", "Spine3", (255, 55, 20), 350.0),
    CollisionMaterial("CLAVICLE_LEFT", "Clavicle Left", (255, 55, 20), 350.0),
    CollisionMaterial("UPPER_ARM_LEFT", "Upper Arm Left", (185, 100, 85), 350.0),
    CollisionMaterial("LOWER_ARM_LEFT", "Lower Arm Left", (185, 100, 85), 350.0),
    CollisionMaterial("HAND_LEFT", "Hand Left", (185, 100, 85), 350.0),
    CollisionMaterial("CLAVICLE_RIGHT", "Clavicle Right", (255, 55, 20), 350.0),
    CollisionMaterial("UPPER_ARM_RIGHT", "Upper Arm Right", (185, 100, 85), 350.0),
    CollisionMaterial("LOWER_ARM_RIGHT", "Lower Arm Right", (185, 100, 85), 350.0),
    CollisionMaterial("HAND_RIGHT", "Hand Right", (185, 100, 85), 350.0),
    CollisionMaterial("NECK", "Neck", (255, 55, 20), 350.0),
    CollisionMaterial("HEAD", "Head", (255, 55, 20), 350.0),
    CollisionMaterial("ANIMAL_DEFAULT", "Animal Default", (255, 55, 20), 350.0),
    CollisionMaterial("PROP_ROCK", "Prop Rock", (185, 185, 185), 3000.0),
    CollisionMaterial("PROP_STONE", "Prop Stone", (185, 185, 185), 7000.0),
    CollisionMaterial("TAR_PAPER", "Tar Paper", (155, 130, 95), 6300.0),
    CollisionMaterial("AM_BASE_WOOD_RAILROAD", "Am Base Wood Railroad", (155, 130, 95), 1400.0),
    CollisionMaterial("WOOD_RAILROAD", "Wood Railroad", (155, 130, 95), 1400.0),
    CollisionMaterial("BONE_LIGHT", "Bone Light", (225, 220, 200), 4200.0),
    CollisionMaterial("BONE_HEAVY", "Bone Heavy", (225, 220, 200), 4200.0),
    CollisionMaterial("WOOD_ROTTEN", "Wood Rotten", (155, 130, 95), 1400.0),
]


def collision_material_shader_expr(r: float, g: float, b: float) -> expr.ShaderExpr:
    return bsdf_diffuse(
        color=vec(r, g, b),
    )


def create_collision_material_from_index(index: int, game: SollumzGame) -> Material:
    game = SollumzGame.RDR
    matinfo = rdr_collisionmats[0]

    try:
        matinfo = rdr_collisionmats[index]
    except IndexError:
        logger.warning(f"Invalid material index '{index}'! Setting to default...")

    r, g, b = matinfo.color
    r /= 255
    g /= 255
    b /= 255

    mat = compile_to_material(matinfo.name, collision_material_shader_expr(r, g, b))
    mat.sollum_type = MaterialType.COLLISION
    mat.sollum_game_type = game
    mat.collision_properties.collision_index = index
    mat.diffuse_color = r, g, b, 1.0
    return mat


def material_hash(name: str) -> int:
    """The game's 16 bit hash of a collision material's name (RedForge's `material_hash`), of the name in capitals."""
    if not name:
        return 12667
    h = 0
    for c in name:
        h = ((ord(c) & 0xFF) + h * 16) & 0xFFFFFFFF
        top = h & 0xF0000000
        if top:
            h ^= top ^ (top >> 24)
    return h % 0x7FED + 18


_rdr_names_by_hash: dict[int, str] = {}


def rdr_material_name(name) -> str:
    """The name of an RDR collision material as the XML has it. RedForge writes the material's hash as a number
    (a model's file has only that), where CodeWalker's XML has the name: the number becomes its name again."""
    text = str(name).strip()
    if not text.isdigit():
        return text
    if not _rdr_names_by_hash:
        _rdr_names_by_hash.update({material_hash(mat.name): mat.name for mat in rdr_collisionmats})
    return _rdr_names_by_hash.get(int(text), text)


def create_collision_material_from_name(name: str, game: SollumzGame):
    matinfo_index = None
    name = rdr_material_name(name)

    mats = rdr_collisionmats

    for i, mat in enumerate(mats):
        if mat.name.lower() == name.lower():
            matinfo_index = i
            break
    if matinfo_index is None:
        logger.warning(
            f"Invalid material '{name}'! Setting to default...")
        matinfo_index = 0

    return create_collision_material_from_index(matinfo_index, game)

