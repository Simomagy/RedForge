# Sollumz RDR Fragment Export Patch v2

This build changes the first-pass RDR fragment exporter to write a more schema-faithful RDR YFT XML layout.

## Main changes
- Writes `RDR2Fragment` root for RDR fragment export
- Converts exported fragment wrapper from GTA-style `Fragment` layout into RDR-style fragment layout
- Converts main fragment drawable to `Drawable` with `FragName` and `FragMatrix`
- Converts child physics drawables to RDR fragment drawable layout
- Converts physics LOD/group/children into RDR-style `PhysicsLODGroup` / `PhysicsLOD1` structure
- Preserves imported RDR metadata through Blender custom properties when available:
  - `NmAssetID`
  - `BreakAndDamageFlags`
  - `Unknown_84h`
  - archetype `TypeFlags`
  - drawable `FlagsHigh/Med/Low/Vlow`
  - fragment drawable `FragName`
- Keeps v1 exporter unlock and tolerance behavior

## Notes
- This is still a first-pass compatibility patch. It is intended to get much closer to original RDR schema and improve CodeWalker visibility versus v1.
- It may still need follow-up fixes for exact physics semantics, special unknown fields, or asset-specific values.
- For best results, re-import the original RDR fragment using this v2 build before exporting, so the importer can cache original RDR metadata onto Blender objects.
