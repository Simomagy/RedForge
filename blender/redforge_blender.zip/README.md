# RedForge for Blender

Blender add-on for Red Dead Redemption 2 / RedM models, collisions, animations and maps, linked to
[RedForge](https://github.com/Simomagy/RedForge): Edit in Blender brings the map's objects in, Send Changes puts
the edited models back in the project.

A fork of [Sollumz RDR](https://github.com/Sollumz/Sollumz-RDR) by Skylumz, Colton and alexguirre, under the same
licence (GPL-3.0-or-later, see `LICENSE`). It replaces Sollumz and Sollumz RDR: only one of them can be enabled.

- Blender 5.3 or newer.
- RDR2 only: a GTA V file is refused when imported.
- `.blend` files made with Sollumz RDR open as they are (the data keeps Sollumz's names: `sollum_type`...).

## Layout

- One sidebar tab, RedForge: the link, and the Guide. The tools by kind of file are under them with Expert Tools on.
- `guide/`: the Guide (`core.py` its panel and what a flow and a step are, `ydr.py` the flow for a static model, `mlo.py` the one for an interior, `ybn.py` the one for a collision of its own).
- `redforge/`: the link with RedForge (`link.py` the connection, `bridge.py` the operators and the panel).
- `ydr/`, `ydd/`, `yft/`, `ybn/`, `ycd/`, `ytyp/`, `ymap/`, `ynv/`: one folder per game file type.
- `cwxml/`: the XML of each type, as RedForge and CodeWalker write it.
- `tests/roundtrip.py`: imports every model in a folder and exports it again, in a Blender with its own profile.
- `tests/panels.py`: in a Blender with a window, lets every panel draw for each kind of object.
- `tests/guide.py`: the Guide's flow from plain meshes to the exported files, every step drawn when there's a window.

## Checking a change

```
pwsh tests/run.ps1
```

Builds the add-on, installs it in a throwaway Blender profile (yours isn't touched) and prints, per model, whether it
imported and exported. Models come from RedForge's exports (`%LOCALAPPDATA%\RedForge\Blender\edit`) unless `-Samples`
says otherwise; `-Blender` picks the executable, `-Panels` also runs the panels test (a Blender window opens for a minute).

## What a model loses going through Blender

``npwsh tests/fidelity.ps1 -Rf ../redforge-rs/target/debug/rf.exe -Summary
``n
Imports and exports each model, converts the original and the export to a game file and back with RedForge's `rf`,
and compares the two (`tests/compare_xml.py`): what's listed is what the game file got differently. Without
`-Summary` every difference is printed; `-Only crate` does the models with that in their name.

## Shipping it with RedForge

```
./build.sh -o ../redforge-rs/blender/redforge_blender.zip
```

Builds the extension's .zip where RedForge's installers take it from (without `tests/`). On Windows,
`pwsh build.ps1 -Out ../redforge-rs/blender/redforge_blender.zip` does the same. Both take the Blender to build
with (`-b`, `-Blender`) when it isn't the one found by itself.
