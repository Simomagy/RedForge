# RedForge for Blender

Blender add-on for Red Dead Redemption 2 / RedM models, collisions, animations and maps, linked to
[RedForge](https://github.com/Simomagy/RedForge): Edit in Blender brings the map's objects in, Send Changes puts
the edited models back in the project.

A fork of [Sollumz RDR](https://github.com/Sollumz/Sollumz-RDR) by Skylumz, Colton and alexguirre, under the same
licence (GPL-3.0-or-later, see `LICENSE`). It replaces Sollumz and Sollumz RDR: only one of them can be enabled.

- Blender 5.3 or newer.
- RDR2 only: a GTA V file is refused when imported.
- `.blend` files made with Sollumz RDR open as they are (the data keeps Sollumz's names: `sollum_type`...).

## Layout

- One sidebar tab, RedForge: the link, files and view on top, the tools by kind of file under them.
- `redforge/`: the link with RedForge (`link.py` the connection, `bridge.py` the operators and the panel).
- `ydr/`, `ydd/`, `yft/`, `ybn/`, `ycd/`, `ytyp/`, `ymap/`, `ynv/`: one folder per game file type.
- `cwxml/`: the XML of each type, as RedForge and CodeWalker write it.
- `tests/roundtrip.py`: imports every model in a folder and exports it again, in a Blender with its own profile.
- `tests/panels.py`: in a Blender with a window, lets every panel draw for each kind of object.

## Checking a change

```
pwsh tests/run.ps1
```

Builds the add-on, installs it in a throwaway Blender profile (yours isn't touched) and prints, per model, whether it
imported and exported. Models come from RedForge's exports (`%LOCALAPPDATA%\RedForge\Blender\edit`) unless `-Samples`
says otherwise; `-Blender` picks the executable, `-Panels` also runs the panels test (a Blender window opens for a minute).
