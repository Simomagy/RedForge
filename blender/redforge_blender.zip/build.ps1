# Builds the add-on as a Blender extension: one .zip, installed in Blender with Install from Disk.
# RedForge's installers ship it: -Out <redforge-rs>/blender/redforge_blender.zip puts it where they take it from.
param(
    [string]$Out = (Join-Path $PSScriptRoot "redforge_blender.zip"),
    [string]$Blender = ""
)

if (-not $Blender) {
    $Blender = Get-ChildItem "C:\Program Files\Blender Foundation\*\blender.exe" | Sort-Object FullName | Select-Object -Last 1 -ExpandProperty FullName
}
if (-not $Blender -or -not (Test-Path $Blender)) { throw "Blender not found: pass -Blender <path to blender.exe>" }

& $Blender --command extension build --source-dir $PSScriptRoot --output-filepath $Out 2>&1 | Select-Object -Last 1
if (-not (Test-Path $Out)) { throw "The add-on wasn't built" }