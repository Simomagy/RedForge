"""Textures as the game's files take them: RedForge reads a model's or a texture dictionary's textures as
<name>.dds from the folder next to the XML, and nothing else."""
import os
import shutil
import struct

import bpy
import numpy as np

from .. import logger

DXGI_B8G8R8A8_UNORM = 87


def texture_name(image: bpy.types.Image) -> str:
    """The texture's name in the game: its file's name, without the extension."""
    return os.path.splitext(os.path.basename(image.filepath))[0] if image is not None else ""


def dds_bytes(pixels: np.ndarray) -> bytes:
    """An uncompressed DDS (B8G8R8A8, DX10 header) with its mip levels, of height x width x 4 RGBA floats, top row
    first."""
    height, width = pixels.shape[:2]
    # Mip levels the way the game's textures have them: each half the one before, down to 4 pixels on the short side.
    # Only for sizes that are powers of two: the game's files have no room worked out for the levels of any other.
    power_of_two = (width & (width - 1)) == 0 and (height & (height - 1)) == 0
    count = max(1, min(width, height).bit_length() - 2) if power_of_two else 1
    levels = []
    level = pixels.astype(np.float32)
    for _ in range(count):
        bgra = np.clip(level[:, :, (2, 1, 0, 3)] * 255.0 + 0.5, 0, 255).astype(np.uint8)
        levels.append(bgra.tobytes())
        if level.shape[0] > 1 and level.shape[1] > 1:  # (the next one: each pixel the average of the 2x2 under it)
            level = (level[0::2, 0::2] + level[1::2, 0::2] + level[0::2, 1::2] + level[1::2, 1::2]) * 0.25
    header = struct.pack(
        "<4s7I44x8I5I", b"DDS ", 124, 0x1 | 0x2 | 0x4 | 0x8 | 0x1000 | 0x20000, height, width, width * 4, 0, len(levels),
        32, 0x4, int.from_bytes(b"DX10", "little"), 0, 0, 0, 0, 0,  # (the pixel format: in the DX10 header)
        0x1000 | 0x8 | 0x400000, 0, 0, 0, 0)
    return header + struct.pack("<5I", DXGI_B8G8R8A8_UNORM, 3, 0, 1, 0) + b"".join(levels)


def write_texture(image: bpy.types.Image, folder: str) -> bool:
    """Writes the image as <its texture name>.dds in the folder: its own file when that's a DDS (kept as it was
    compressed), made from its pixels otherwise. False if the image has nothing to write."""
    name = texture_name(image)
    if not name:
        return False
    source = bpy.path.abspath(image.filepath, library=image.library)
    destination = os.path.join(folder, f"{name}.dds")
    os.makedirs(folder, exist_ok=True)
    if source.lower().endswith(".dds") and os.path.isfile(source):
        if not os.path.exists(destination) or not os.path.samefile(source, destination):
            shutil.copyfile(source, destination)
        return True
    width, height = image.size
    if width == 0 or height == 0:
        logger.warning(f"Texture '{image.name}' has no pixels ({source or 'no file'}): it isn't written.")
        return False
    if (width & (width - 1)) or (height & (height - 1)):
        logger.warning(f"Texture '{name}' is {width}x{height}: not powers of two, so it's written without mip levels "
                       "(it shimmers from far away). Sizes like 512x512 or 1024x2048 get them.")
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    with open(destination, "wb") as file:
        file.write(dds_bytes(pixels.reshape(height, width, 4)[::-1]))  # (Blender's rows start at the bottom)
    return True
