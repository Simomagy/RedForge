#!/bin/sh
# Builds the add-on as a Blender extension: one .zip, installed in Blender with Install from Disk.
# RedForge's installers ship it: -o <redforge-rs>/blender/redforge_blender.zip puts it where they take it from.
# (build.ps1 does the same on Windows.)
#
#   ./build.sh [-o <the .zip to write>] [-b <blender>]
set -e
here=$(cd "$(dirname "$0")" && pwd)
out="$here/redforge_blender.zip"
blender=${BLENDER:-blender}
while [ $# -gt 0 ]; do
    case "$1" in
        -o|--out) out=$2; shift 2 ;;
        -b|--blender) blender=$2; shift 2 ;;
        -h|--help) sed -n '2,6p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "Unknown option: $1 (see --help)" >&2; exit 2 ;;
    esac
done
if ! command -v "$blender" >/dev/null 2>&1; then
    echo "Blender not found: pass -b <path to blender>, or set BLENDER" >&2
    exit 1
fi
case "$out" in /*) ;; *) out="$PWD/$out" ;; esac  # (Blender is run from elsewhere: a path of its own)

# Built to a new file, then put in place: a build that fails leaves the .zip that was there.
new=$(mktemp -u "${TMPDIR:-/tmp}/redforge_blender.XXXXXX").zip
trap 'rm -f "$new"' EXIT
log=$("$blender" --command extension build --source-dir "$here" --output-filepath "$new" 2>&1) || true
if [ ! -s "$new" ]; then
    printf '%s\n' "$log" >&2  # (what Blender said: said only when it matters)
    echo "The add-on wasn't built" >&2
    exit 1
fi
mkdir -p "$(dirname "$out")"
out="$(cd "$(dirname "$out")" && pwd)/$(basename "$out")"
mv -f "$new" "$out"
echo "Built $out"
