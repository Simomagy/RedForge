from abc import ABC as AbstractClass
from .element import (
    ElementTree,
    ListProperty,
    TextProperty,
    ValueProperty,
    VectorProperty,
    Vector2Property
)


class Link(ElementTree):
    tag_name = "Item"

    def __init__(self):
        super().__init__()
        self.to_area_id = ValueProperty("ToAreaID")
        self.to_node_id = ValueProperty("ToNodeID")
        self.flags_0 = ValueProperty("Flags0")
        self.flags_1 = ValueProperty("Flags1")
        self.flags_2 = ValueProperty("Flags2")
        self.length = ValueProperty("LinkLength")


class LinkList(ListProperty):
    list_type = Link
    tag_name = "Links"


class Node(ElementTree):
    tag_name = "Item"

    def __init__(self):
        super().__init__()
        self.area_id = ValueProperty("AreaID")
        self.node_id = ValueProperty("NodeID")
        self.streetname = TextProperty("StreetName")
        self.area_id = VectorProperty("Position")
        self.flags_0 = ValueProperty("Flags0")
        self.flags_1 = ValueProperty("Flags1")
        self.flags_2 = ValueProperty("Flags2")
        self.flags_3 = ValueProperty("Flags3")
        self.flags_4 = ValueProperty("Flags4")
        self.flags_5 = ValueProperty("Flags5")
        self.links = LinkList()

