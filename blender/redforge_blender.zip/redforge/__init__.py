"""RedForge: the link with the map editor (Edit in Blender, Send Changes)."""
